package com.employee.servlet;

import javax.imageio.ImageIO;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

/**
 * 图形验证码：生成 4 位字符，存入 session("captchaCode")，输出 PNG。
 */
@WebServlet("/captcha")
public class CaptchaServlet extends HttpServlet {

    private static final String CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final int WIDTH = 120;
    private static final int HEIGHT = 40;
    private static final int CODE_LEN = 4;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Random random = new Random();
        StringBuilder code = new StringBuilder();
        for (int i = 0; i < CODE_LEN; i++) {
            code.append(CHARS.charAt(random.nextInt(CHARS.length())));
        }

        HttpSession session = req.getSession();
        session.setAttribute("captchaCode", code.toString());

        BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // 背景
        g.setColor(new Color(0xf0, 0xf3, 0xf8));
        g.fillRect(0, 0, WIDTH, HEIGHT);

        // 干扰线
        for (int i = 0; i < 6; i++) {
            g.setColor(randomColor(180, 220));
            g.drawLine(random.nextInt(WIDTH), random.nextInt(HEIGHT),
                    random.nextInt(WIDTH), random.nextInt(HEIGHT));
        }

        // 噪点
        for (int i = 0; i < 60; i++) {
            g.setColor(randomColor(150, 210));
            g.fillRect(random.nextInt(WIDTH), random.nextInt(HEIGHT), 1, 1);
        }

        // 字符
        for (int i = 0; i < CODE_LEN; i++) {
            g.setColor(randomColor(20, 90));
            g.setFont(new Font("Arial", Font.BOLD, 26 + random.nextInt(4)));
            double angle = (random.nextDouble() - 0.5) * 0.5;
            int x = 15 + i * 26;
            int y = 30;
            g.rotate(angle, x, y);
            g.drawString(String.valueOf(code.charAt(i)), x, y);
            g.rotate(-angle, x, y);
        }

        g.dispose();

        resp.setContentType("image/png");
        resp.setDateHeader("Expires", 0);
        resp.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        resp.setHeader("Pragma", "no-cache");
        ImageIO.write(image, "png", resp.getOutputStream());
    }

    private Color randomColor(int min, int max) {
        Random r = new Random();
        int range = max - min;
        return new Color(min + r.nextInt(range), min + r.nextInt(range), min + r.nextInt(range));
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        doGet(req, resp);
    }
}