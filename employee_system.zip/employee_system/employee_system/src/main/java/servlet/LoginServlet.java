package com.employee.servlet;

import com.employee.dao.LoginLogDao;
import com.employee.dao.UserDao;
import com.employee.entity.User;
import com.employee.util.PasswordUtil;
import com.employee.util.WebUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final int MAX_FAIL = 5;
    private static final int LOCK_MINUTES = 15;

    private final UserDao userDao = new UserDao();
    private final LoginLogDao loginLogDao = new LoginLogDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");

        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String captcha = req.getParameter("captcha");
        String ip = WebUtil.getClientIp(req);
        LocalDateTime now = LocalDateTime.now();

        HttpSession session = req.getSession();

        if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            req.setAttribute("error", "用户名和密码不能为空");
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
            return;
        }
        username = username.trim();

        // 1. 校验验证码（一次性，用完即清除）
        String expected = (String) session.getAttribute("captchaCode");
        session.removeAttribute("captchaCode");
        if (expected == null || captcha == null || !expected.equalsIgnoreCase(captcha.trim())) {
            req.setAttribute("error", "验证码错误或已过期");
            req.setAttribute("oldUsername", username);
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
            return;
        }

        // 2. 查询用户
        User user = userDao.findByUsername(username);

        // 3. 锁定判断
        if (user != null && user.getLockUntil() != null && user.getLockUntil().isAfter(now)) {
            long remain = Duration.between(now, user.getLockUntil()).toMinutes() + 1;
            req.setAttribute("error", "账号已被锁定，请 " + remain + " 分钟后再试");
            req.setAttribute("oldUsername", username);
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
            return;
        }

        // 4. 密码校验
        boolean ok = user != null && PasswordUtil.check(password, user.getPassword());

        if (ok) {
            userDao.updateAfterSuccessLogin(user.getId(), now, ip);
            user.setPassword(null); // 不把密码放入 Session
            session.setAttribute("loginUser", user);
            loginLogDao.log(username, ip, true, "登录成功");
            resp.sendRedirect(req.getContextPath() + "/index.jsp");
        } else {
            int newFail = (user == null ? 0 : user.getFailedCount()) + 1;
            boolean lock = newFail >= MAX_FAIL;
            LocalDateTime lockUntil = lock ? now.plusMinutes(LOCK_MINUTES) : null;
            if (user != null) {
                userDao.updateAfterFailedLogin(user.getId(), newFail, lockUntil);
            }
            loginLogDao.log(username, ip, false, lock ? "密码错误次数过多，账号已锁定" : "用户名或密码错误");
            req.setAttribute("error", lock
                    ? "密码错误次数过多，账号已锁定 " + LOCK_MINUTES + " 分钟"
                    : "用户名或密码错误");
            req.setAttribute("oldUsername", username);
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
        }
    }
}