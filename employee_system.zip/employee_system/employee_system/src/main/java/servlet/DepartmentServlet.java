package com.employee.servlet;

import com.employee.dao.DepartmentDao;
import com.employee.entity.Department;
import com.employee.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/department")
public class DepartmentServlet extends HttpServlet {

    private final DepartmentDao departmentDao = new DepartmentDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");

        Object loginUserObj = req.getSession().getAttribute("loginUser");
        if (loginUserObj == null) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        if (!"admin".equalsIgnoreCase(((User) loginUserObj).getRole())) {
            resp.sendRedirect(req.getContextPath() + "/index.jsp");
            return;
        }

        String action = req.getParameter("action");

        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "list":
                listDepartments(req, resp);
                break;
            case "add":
                addPage(req, resp);
                break;
            case "edit":
                editPage(req, resp);
                break;
            case "delete":
                deleteDepartment(req, resp);
                break;
            default:
                listDepartments(req, resp);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");

        Object loginUserObj = req.getSession().getAttribute("loginUser");
        if (loginUserObj == null) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        if (!"admin".equalsIgnoreCase(((User) loginUserObj).getRole())) {
            resp.sendRedirect(req.getContextPath() + "/index.jsp");
            return;
        }

        String action = req.getParameter("action");

        if ("insert".equals(action)) {
            insertDepartment(req, resp);
        } else if ("update".equals(action)) {
            updateDepartment(req, resp);
        } else {
            resp.sendRedirect(req.getContextPath() + "/department");
        }
    }

    private void listDepartments(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Department> departments = departmentDao.findAll();
        req.setAttribute("departments", departments);
        req.getRequestDispatcher("/department_list.jsp").forward(req, resp);
    }

    private void addPage(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/department_add.jsp").forward(req, resp);
    }

    private void editPage(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idStr = req.getParameter("id");
        if (idStr != null) {
            int id = Integer.parseInt(idStr);
            Department department = departmentDao.findById(id);
            req.setAttribute("department", department);
            req.getRequestDispatcher("/department_edit.jsp").forward(req, resp);
        } else {
            resp.sendRedirect(req.getContextPath() + "/department");
        }
    }

    private void insertDepartment(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Department department = new Department();
        department.setName(req.getParameter("name"));
        department.setManager(req.getParameter("manager"));
        department.setDescription(req.getParameter("description"));
        departmentDao.insert(department);
        resp.sendRedirect(req.getContextPath() + "/department");
    }

    private void updateDepartment(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String idStr = req.getParameter("id");
        if (idStr != null) {
            Department department = new Department();
            department.setId(Integer.parseInt(idStr));
            department.setName(req.getParameter("name"));
            department.setManager(req.getParameter("manager"));
            department.setDescription(req.getParameter("description"));
            departmentDao.update(department);
        }
        resp.sendRedirect(req.getContextPath() + "/department");
    }

    private void deleteDepartment(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String idStr = req.getParameter("id");
        if (idStr != null) {
            departmentDao.delete(Integer.parseInt(idStr));
        }
        resp.sendRedirect(req.getContextPath() + "/department");
    }
}