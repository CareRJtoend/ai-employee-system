package com.employee.servlet;

import com.employee.dao.AttendanceDao;
import com.employee.dao.DepartmentDao;
import com.employee.dao.EmployeeDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/api/dashboard")
public class DashboardServlet extends HttpServlet {

    private final EmployeeDao employeeDao = new EmployeeDao();
    private final DepartmentDao departmentDao = new DepartmentDao();
    private final AttendanceDao attendanceDao = new AttendanceDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("loginUser") == null) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            resp.setContentType("application/json;charset=UTF-8");
            resp.getWriter().write("{\"error\":\"未登录\"}");
            return;
        }

        resp.setContentType("application/json;charset=UTF-8");
        resp.setCharacterEncoding("UTF-8");

        int employeeTotal = employeeDao.countAll();
        int departmentTotal = departmentDao.countAll();
        int todayCheckIn = attendanceDao.todayCheckIn();
        int todayAbnormal = attendanceDao.todayAbnormal();
        List<Map<String, Object>> deptDist = employeeDao.countGroupByDept();
        Map<String, Integer> trendMap = buildTrendMap();
        List<Map<String, Object>> recent = employeeDao.findRecentHired(5);

        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"employeeTotal\":").append(employeeTotal).append(",");
        sb.append("\"departmentTotal\":").append(departmentTotal).append(",");
        sb.append("\"todayCheckIn\":").append(todayCheckIn).append(",");
        sb.append("\"todayAbnormal\":").append(todayAbnormal).append(",");

        sb.append("\"deptDist\":[");
        for (int i = 0; i < deptDist.size(); i++) {
            Map<String, Object> row = deptDist.get(i);
            if (i > 0) sb.append(",");
            sb.append("{\"name\":").append(str(String.valueOf(row.get("name"))))
                    .append(",\"value\":").append(((Number) row.get("value")).intValue());
            sb.append("}");
        }
        sb.append("],");

        DateTimeFormatter labelFmt = DateTimeFormatter.ofPattern("MM-dd");
        List<String> days = new ArrayList<>();
        List<Integer> counts = new ArrayList<>();
        LocalDate today = LocalDate.now();
        for (int i = 6; i >= 0; i--) {
            LocalDate d = today.minusDays(i);
            days.add(d.format(labelFmt));
            counts.add(trendMap.getOrDefault(d.format(DateTimeFormatter.ISO_LOCAL_DATE), 0));
        }
        sb.append("\"trendDays\":[");
        for (int i = 0; i < days.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(str(days.get(i)));
        }
        sb.append("],\"trendCounts\":[");
        for (int i = 0; i < counts.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(counts.get(i));
        }
        sb.append("],");

        sb.append("\"recent\":[");
        for (int i = 0; i < recent.size(); i++) {
            Map<String, Object> row = recent.get(i);
            if (i > 0) sb.append(",");
            sb.append("{")
                    .append("\"name\":").append(str(safe(row.get("name")))).append(",")
                    .append("\"gender\":").append(str(safe(row.get("gender")))).append(",")
                    .append("\"position\":").append(str(safe(row.get("position")))).append(",")
                    .append("\"deptName\":").append(str(safe(row.get("deptName")))).append(",")
                    .append("\"hireDate\":").append(str(safe(row.get("hireDate"))));
            sb.append("}");
        }
        sb.append("]");

        sb.append("}");

        PrintWriter out = resp.getWriter();
        out.write(sb.toString());
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }

    private Map<String, Integer> buildTrendMap() {
        Map<String, Integer> map = new HashMap<>();
        for (Map<String, Object> row : attendanceDao.last7Days()) {
            map.put(String.valueOf(row.get("date")), ((Number) row.get("count")).intValue());
        }
        return map;
    }

    private String safe(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    private String str(String s) {
        if (s == null) return "\"\"";
        StringBuilder r = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': r.append("\\\""); break;
                case '\\': r.append("\\\\"); break;
                case '\n': r.append("\\n"); break;
                case '\r': r.append("\\r"); break;
                case '\t': r.append("\\t"); break;
                default:
                    if (c < 0x20) r.append(String.format("\\u%04x", (int) c));
                    else r.append(c);
            }
        }
        r.append("\"");
        return r.toString();
    }
}