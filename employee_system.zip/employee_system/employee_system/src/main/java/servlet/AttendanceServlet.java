package com.employee.servlet;

import com.employee.dao.AttendanceDao;
import com.employee.dao.EmployeeDao;
import com.employee.entity.Attendance;
import com.employee.entity.Employee;
import com.employee.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/attendance")
public class AttendanceServlet extends HttpServlet {

    private final AttendanceDao attendanceDao = new AttendanceDao();
    private final EmployeeDao employeeDao = new EmployeeDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");

        HttpSession session = req.getSession(false);
        User loginUser = session == null ? null : (User) session.getAttribute("loginUser");
        if (loginUser == null) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        boolean admin = "admin".equalsIgnoreCase(loginUser.getRole());

        String action = req.getParameter("action");

        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "list":
                listAttendance(req, resp);
                break;
            case "myRecords":
                myRecords(req, resp);
                break;
            case "checkIn":
                checkIn(req, resp);
                break;
            case "checkOut":
                checkOut(req, resp);
                break;
            case "makeup":
                if (!admin) { resp.sendRedirect(req.getContextPath() + "/attendance"); return; }
                makeup(req, resp);
                break;
            case "markLate":
                if (!admin) { resp.sendRedirect(req.getContextPath() + "/attendance"); return; }
                markLate(req, resp);
                break;
            case "forceCheckOut":
                if (!admin) { resp.sendRedirect(req.getContextPath() + "/attendance"); return; }
                forceCheckOut(req, resp);
                break;
            case "deleteRecord":
                if (!admin) { resp.sendRedirect(req.getContextPath() + "/attendance"); return; }
                deleteRecord(req, resp);
                break;
            default:
                listAttendance(req, resp);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }

    private void listAttendance(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Attendance> records = attendanceDao.findAll();
        req.setAttribute("records", records);
        req.setAttribute("abnormalRecords", attendanceDao.findTodayAbnormal());
        req.getRequestDispatcher("/attendance_list.jsp").forward(req, resp);
    }

    private void myRecords(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String empIdStr = req.getParameter("employeeId");
        if (empIdStr != null) {
            int employeeId = Integer.parseInt(empIdStr);
            List<Attendance> records = attendanceDao.findByEmployee(employeeId);
            Employee employee = employeeDao.findById(employeeId);
            req.setAttribute("records", records);
            req.setAttribute("employee", employee);
            req.getRequestDispatcher("/attendance_my.jsp").forward(req, resp);
        } else {
            resp.sendRedirect(req.getContextPath() + "/attendance");
        }
    }

    private void checkIn(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String empIdStr = req.getParameter("employeeId");
        if (empIdStr != null) {
            attendanceDao.checkIn(Integer.parseInt(empIdStr));
        }
        resp.sendRedirect(req.getContextPath() + "/attendance");
    }

    private void checkOut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String empIdStr = req.getParameter("employeeId");
        if (empIdStr != null) {
            attendanceDao.checkOut(Integer.parseInt(empIdStr));
        }
        resp.sendRedirect(req.getContextPath() + "/attendance");
    }

    private void makeup(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String empIdStr = req.getParameter("employeeId");
        String date = req.getParameter("date");
        if (empIdStr != null && date != null && !date.trim().isEmpty()) {
            attendanceDao.makeup(Integer.parseInt(empIdStr), date.trim());
        }
        resp.sendRedirect(req.getContextPath() + "/attendance");
    }

    private void markLate(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String idStr = req.getParameter("id");
        if (idStr != null) {
            attendanceDao.markLate(Integer.parseInt(idStr));
        }
        resp.sendRedirect(req.getContextPath() + "/attendance");
    }

    private void forceCheckOut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String idStr = req.getParameter("id");
        if (idStr != null) {
            attendanceDao.forceCheckOut(Integer.parseInt(idStr));
        }
        resp.sendRedirect(req.getContextPath() + "/attendance");
    }

    private void deleteRecord(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String idStr = req.getParameter("id");
        if (idStr != null) {
            attendanceDao.deleteById(Integer.parseInt(idStr));
        }
        resp.sendRedirect(req.getContextPath() + "/attendance");
    }
}