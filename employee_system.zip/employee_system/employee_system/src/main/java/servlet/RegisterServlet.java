package com.employee.servlet;

import com.employee.dao.UserDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private final UserDao userDao = new UserDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/register.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");

        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String confirmPassword = req.getParameter("confirmPassword");

        if (username == null || username.trim().isEmpty()) {
            req.setAttribute("error", "用户名不能为空");
            req.setAttribute("oldUsername", username);
            req.getRequestDispatcher("/register.jsp").forward(req, resp);
            return;
        }
        username = username.trim();

        if (username.length() < 3 || username.length() > 20) {
            req.setAttribute("error", "用户名长度需在 3-20 个字符之间");
            req.setAttribute("oldUsername", username);
            req.getRequestDispatcher("/register.jsp").forward(req, resp);
            return;
        }

        if (password == null || password.length() < 4) {
            req.setAttribute("error", "密码长度至少 4 位");
            req.setAttribute("oldUsername", username);
            req.getRequestDispatcher("/register.jsp").forward(req, resp);
            return;
        }

        if (!password.equals(confirmPassword)) {
            req.setAttribute("error", "两次输入的密码不一致");
            req.setAttribute("oldUsername", username);
            req.getRequestDispatcher("/register.jsp").forward(req, resp);
            return;
        }

        if (userDao.isUsernameExists(username)) {
            req.setAttribute("error", "用户名「" + username + "」已被占用，请换一个");
            req.setAttribute("oldUsername", username);
            req.getRequestDispatcher("/register.jsp").forward(req, resp);
            return;
        }

        boolean success = userDao.register(username, password);
        if (success) {
            req.setAttribute("success", "注册成功！请使用新账号登录");
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
        } else {
            req.setAttribute("error", "注册失败，请稍后重试");
            req.setAttribute("oldUsername", username);
            req.getRequestDispatcher("/register.jsp").forward(req, resp);
        }
    }
}