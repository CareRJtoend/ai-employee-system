package com.employee.servlet;

import com.employee.dao.AttendanceDao;
import com.employee.dao.DepartmentDao;
import com.employee.dao.EmployeeDao;
import com.employee.entity.Department;
import com.employee.entity.Employee;
import com.employee.service.AIService;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * AI 对话接口：/api/ai/chat
 * 请求：{ "message": "用户问题" }
 * 响应：{ "success": true, "reply": "AI回答" }
 * 多轮对话：历史消息存于 Session，每个用户独立上下文。
 */
@WebServlet("/api/ai/chat")
public class AIChatServlet extends HttpServlet {

    /** Session 中历史消息的 key，元素为 {"role": "...", "content": "..."} */
    private static final String HISTORY_KEY = "aiChatHistory";

    /** 上下文最大消息条数（system 除外），超出后丢弃最早的，防止 Session 膨胀 */
    private static final int MAX_HISTORY_MESSAGES = 20;

    private final AIService aiService = new AIService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws java.io.IOException {
        HttpSession session = req.getSession(false);
        if (session != null && "1".equals(req.getParameter("clear"))) {
            session.removeAttribute(HISTORY_KEY);
        }
        resp.setContentType("application/json;charset=UTF-8");
        resp.getWriter().write("{\"success\":true}");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws java.io.IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json;charset=UTF-8");
        resp.setHeader("Cache-Control", "no-cache");

        try {
            String body = readBody(req);
            String message = extractJsonString(body, "message");

            if (message == null || message.trim().isEmpty()) {
                resp.getWriter().write(jsonResponse(false, "消息不能为空", null));
                return;
            }
            message = message.trim();

            HttpSession session = req.getSession();

            // 1. 取历史并追加本轮用户提问
            List<Map<String, String>> history = getOrCreateHistory(session);
            history.add(buildMessage("user", message));

            // 2. 组装发给模型的消息：实时数据人设 + 历史（含本轮问题）
            List<Map<String, String>> payload = new ArrayList<>();
            payload.add(buildMessage("system", buildSystemPrompt()));
            payload.addAll(trimHistory(history));

            // 3. 调用 AI
            String reply = aiService.chatWithContext(payload);

            // 兜底提示说明调用失败：不把失败轮次写入历史，保持上下文干净
            if (reply == null || reply.contains("AI 服务暂时不可用")) {
                history.remove(history.size() - 1);
                resp.getWriter().write(jsonResponse(false, "AI 服务暂时不可用，请稍后再试", null));
                return;
            }

            // 4. 回答写回历史，供下一轮多轮对话使用
            history.add(buildMessage("assistant", reply));

            resp.getWriter().write(jsonResponse(true, null, reply));
        } catch (Exception e) {
            resp.getWriter().write(jsonResponse(false, "服务器内部错误：" + e.getMessage(), null));
        }
    }

    // ==================== 实时数据注入 ====================

    /**
     * 构建带实时业务数据的 system 提示词。
     * 每次提问都重新查库，保证 AI 回答的是"此刻"的数据。
     */
    private String buildSystemPrompt() {
        StringBuilder sb = new StringBuilder();
        sb.append("你是一个员工管理系统的智能助手，请用简洁友好的中文回答问题。")
          .append("下面是系统的实时数据快照，当用户询问相关信息时，请严格依据快照内容回答，")
          .append("快照中没有的就如实说明暂无记录，禁止编造数据：\n")
          .append("今天是 ").append(LocalDate.now()).append("。\n");
        try {
            EmployeeDao employeeDao = new EmployeeDao();
            DepartmentDao departmentDao = new DepartmentDao();
            AttendanceDao attendanceDao = new AttendanceDao();

            // 部门与人数
            sb.append("\n【部门人数】\n");
            for (Map<String, Object> row : employeeDao.countGroupByDept()) {
                sb.append("- ").append(row.get("name")).append("：")
                  .append(((Number) row.get("value")).intValue()).append(" 人\n");
            }

            // 在职员工名单（按部门分组，最多输出 150 人防止提示词过长）
            List<Employee> employees = employeeDao.findAll();
            Map<Integer, String> deptNames = new HashMap<>();
            for (Department d : departmentDao.findAll()) {
                deptNames.put(d.getId(), d.getName());
            }
            Map<String, List<String>> byDept = new LinkedHashMap<>();
            for (Employee e : employees) {
                String dn = deptNames.getOrDefault(e.getDeptId(), "未分配部门");
                List<String> members = byDept.computeIfAbsent(dn, k -> new ArrayList<>());
                if (members.size() < 50) {
                    String role = e.getPosition() == null || e.getPosition().isEmpty() ? "" : "（" + e.getPosition() + "）";
                    members.add(e.getName() + role);
                }
            }
            sb.append("\n【员工名单】共 ").append(employees.size()).append(" 人\n");
            for (Map.Entry<String, List<String>> en : byDept.entrySet()) {
                sb.append("- ").append(en.getKey()).append("：")
                  .append(String.join("、", en.getValue())).append("\n");
            }

            // 今日考勤
            sb.append("\n【今日考勤】已签到 ").append(attendanceDao.todayCheckIn())
              .append(" 人，异常 ").append(attendanceDao.todayAbnormal()).append(" 人次。\n");
        } catch (Exception e) {
            sb.append("\n（实时数据加载失败，请引导用户稍后重试）\n");
        }
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, String>> getOrCreateHistory(HttpSession session) {
        Object obj = session.getAttribute(HISTORY_KEY);
        if (obj instanceof List) {
            return (List<Map<String, String>>) obj;
        }
        List<Map<String, String>> history = new ArrayList<>();
        session.setAttribute(HISTORY_KEY, history);
        return history;
    }

    private Map<String, String> buildMessage(String role, String content) {
        Map<String, String> msg = new HashMap<>();
        msg.put("role", role);
        msg.put("content", content);
        return msg;
    }

    /** 只把最近 MAX_HISTORY_MESSAGES 条发给模型 */
    private List<Map<String, String>> trimHistory(List<Map<String, String>> history) {
        int from = Math.max(0, history.size() - MAX_HISTORY_MESSAGES);
        return history.subList(from, history.size());
    }

    /** 读取请求体全文 */
    private String readBody(HttpServletRequest req) throws Exception {
        InputStream is = req.getInputStream();
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        }
        return sb.toString();
    }

    /**
     * 从扁平 JSON 中提取指定 key 的字符串值（本项目无 JSON 库，手动解析）。
     * 支持引号、反斜杠、换行以及 \\uXXXX 等转义的还原。
     */
    private String extractJsonString(String json, String key) {
        if (json == null) {
            return null;
        }
        int keyIdx = json.indexOf("\"" + key + "\"");
        if (keyIdx < 0) {
            return null;
        }
        int colonIdx = json.indexOf(':', keyIdx + key.length() + 2);
        if (colonIdx < 0) {
            return null;
        }
        int quoteIdx = json.indexOf('"', colonIdx + 1);
        if (quoteIdx < 0) {
            return null;
        }

        StringBuilder out = new StringBuilder();
        int i = quoteIdx + 1;
        while (i < json.length()) {
            char c = json.charAt(i);
            if (c == '\\') {
                if (i + 1 >= json.length()) {
                    break;
                }
                char n = json.charAt(i + 1);
                switch (n) {
                    case 'n': out.append('\n'); break;
                    case 't': out.append('\t'); break;
                    case 'r': out.append('\r'); break;
                    case '"': out.append('"'); break;
                    case '\\': out.append('\\'); break;
                    case '/': out.append('/'); break;
                    case 'u':
                        if (i + 5 < json.length()) {
                            out.append((char) Integer.parseInt(json.substring(i + 2, i + 6), 16));
                            i += 4;
                        }
                        break;
                    default: out.append(n); break;
                }
                i += 2;
            } else if (c == '"') {
                break;
            } else {
                out.append(c);
                i++;
            }
        }
        return out.toString();
    }

    /** 拼装响应 JSON */
    private String jsonResponse(boolean success, String error, String reply) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"success\":").append(success);
        if (error != null) {
            sb.append(",\"error\":\"").append(escapeJson(error)).append("\"");
        }
        if (reply != null) {
            sb.append(",\"reply\":\"").append(escapeJson(reply)).append("\"");
        }
        sb.append("}");
        return sb.toString();
    }

    /** JSON 字符串值转义（AI 回答里可能带引号/换行） */
    private String escapeJson(String raw) {
        if (raw == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        return sb.toString();
    }
}