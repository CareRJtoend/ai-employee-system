package com.employee.servlet;

import com.employee.dao.DepartmentDao;
import com.employee.dao.EmployeeDao;
import com.employee.entity.Department;
import com.employee.entity.Employee;
import com.employee.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

@WebServlet("/employee")
public class EmployeeServlet extends HttpServlet {

    private final EmployeeDao employeeDao = new EmployeeDao();
    private final DepartmentDao departmentDao = new DepartmentDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");

        Object loginUserObj = req.getSession().getAttribute("loginUser");
        if (loginUserObj == null) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        if (!"admin".equalsIgnoreCase(((User) loginUserObj).getRole())) {
            resp.sendRedirect(req.getContextPath() + "/index.jsp");
            return;
        }

        String action = req.getParameter("action");

        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "list":
                listEmployees(req, resp);
                break;
            case "search":
                searchEmployees(req, resp);
                break;
            case "add":
                addPage(req, resp);
                break;
            case "edit":
                editPage(req, resp);
                break;
            case "delete":
                deleteEmployee(req, resp);
                break;
            default:
                listEmployees(req, resp);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");

        Object loginUserObj = req.getSession().getAttribute("loginUser");
        if (loginUserObj == null) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        if (!"admin".equalsIgnoreCase(((User) loginUserObj).getRole())) {
            resp.sendRedirect(req.getContextPath() + "/index.jsp");
            return;
        }

        String action = req.getParameter("action");

        if ("insert".equals(action)) {
            insertEmployee(req, resp);
        } else if ("update".equals(action)) {
            updateEmployee(req, resp);
        } else {
            resp.sendRedirect(req.getContextPath() + "/employee");
        }
    }

    private void listEmployees(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Employee> employees = employeeDao.findAll();
        req.setAttribute("employees", employees);
        req.getRequestDispatcher("/employee_list.jsp").forward(req, resp);
    }

    private void searchEmployees(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String keyword = req.getParameter("keyword");
        List<Employee> employees;
        if (keyword != null && !keyword.trim().isEmpty()) {
            employees = employeeDao.search(keyword.trim());
        } else {
            employees = employeeDao.findAll();
        }
        req.setAttribute("employees", employees);
        req.setAttribute("keyword", keyword);
        req.getRequestDispatcher("/employee_list.jsp").forward(req, resp);
    }

    private void addPage(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Department> departments = departmentDao.findAll();
        req.setAttribute("departments", departments);
        req.getRequestDispatcher("/employee_add.jsp").forward(req, resp);
    }

    private void editPage(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idStr = req.getParameter("id");
        if (idStr != null) {
            int id = Integer.parseInt(idStr);
            Employee employee = employeeDao.findById(id);
            List<Department> departments = departmentDao.findAll();
            req.setAttribute("employee", employee);
            req.setAttribute("departments", departments);
            req.getRequestDispatcher("/employee_edit.jsp").forward(req, resp);
        } else {
            resp.sendRedirect(req.getContextPath() + "/employee");
        }
    }

    private void insertEmployee(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Employee employee = buildEmployee(req);
        employeeDao.insert(employee);
        resp.sendRedirect(req.getContextPath() + "/employee");
    }

    private void updateEmployee(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String idStr = req.getParameter("id");
        if (idStr != null) {
            Employee employee = buildEmployee(req);
            employee.setId(Integer.parseInt(idStr));
            employeeDao.update(employee);
        }
        resp.sendRedirect(req.getContextPath() + "/employee");
    }

    private void deleteEmployee(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String idStr = req.getParameter("id");
        if (idStr != null) {
            employeeDao.delete(Integer.parseInt(idStr));
        }
        resp.sendRedirect(req.getContextPath() + "/employee");
    }

    private Employee buildEmployee(HttpServletRequest req) {
        Employee employee = new Employee();
        employee.setName(req.getParameter("name"));
        employee.setGender(req.getParameter("gender"));
        employee.setPhone(req.getParameter("phone"));
        employee.setEmail(req.getParameter("email"));

        String deptIdStr = req.getParameter("deptId");
        if (deptIdStr != null && !deptIdStr.trim().isEmpty()) {
            employee.setDeptId(Integer.parseInt(deptIdStr));
        }

        employee.setPosition(req.getParameter("position"));

        String hireDateStr = req.getParameter("hireDate");
        if (hireDateStr != null && !hireDateStr.trim().isEmpty()) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                employee.setHireDate(sdf.parse(hireDateStr));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        return employee;
    }
}