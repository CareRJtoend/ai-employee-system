package com.employee.dao;

import com.employee.entity.Attendance;
import com.employee.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class AttendanceDao {

    public List<Attendance> findAll() {
        String sql = "SELECT * FROM attendance";
        List<Attendance> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return list;
    }

    public int checkIn(int employeeId) {
        String sql = "INSERT INTO attendance (employee_id, check_in, date) VALUES (?, ?, CURDATE())";
        Connection conn = null;
        PreparedStatement pstmt = null;
        int result = 0;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, employeeId);
            pstmt.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt);
        }
        return result;
    }

    public int checkOut(int employeeId) {
        String sql = "UPDATE attendance SET check_out = ? WHERE employee_id = ? AND date = CURDATE() AND check_out IS NULL";
        Connection conn = null;
        PreparedStatement pstmt = null;
        int result = 0;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
            pstmt.setInt(2, employeeId);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt);
        }
        return result;
    }

    public List<Attendance> findByEmployee(int employeeId) {
        String sql = "SELECT * FROM attendance WHERE employee_id = ? ORDER BY date DESC";
        List<Attendance> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, employeeId);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return list;
    }

    private Attendance mapRow(ResultSet rs) throws SQLException {
        Attendance att = new Attendance();
        att.setId(rs.getInt("id"));
        att.setEmployeeId(rs.getInt("employee_id"));
        att.setCheckIn(rs.getTimestamp("check_in"));
        att.setCheckOut(rs.getTimestamp("check_out"));
        att.setDate(rs.getDate("date"));
        att.setStatus(optString(rs, "status"));
        return att;
    }

    private String optString(ResultSet rs, String column) {
        try {
            return rs.getString(column);
        } catch (SQLException e) {
            return null;
        }
    }

    public int makeup(int employeeId, String date) {
        String sql = "INSERT INTO attendance (employee_id, check_in, date) VALUES (?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;
        int result = 0;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, employeeId);
            pstmt.setTimestamp(2, Timestamp.valueOf(date + " 09:00:00"));
            pstmt.setDate(3, java.sql.Date.valueOf(date));
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt);
        }
        return result;
    }

    public int markLate(int recordId) {
        String sql = "UPDATE attendance SET status = '迟到' WHERE id = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        int result = 0;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, recordId);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt);
        }
        return result;
    }

    public int todayCheckIn() {
        return countQuery("SELECT COUNT(*) FROM attendance WHERE date = CURDATE() AND check_in IS NOT NULL");
    }

    public int todayAbnormal() {
        return countQuery("SELECT COUNT(*) FROM attendance WHERE date = CURDATE() AND check_out IS NULL");
    }

    private int countQuery(String sql) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int count = 0;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return count;
    }

    public List<Map<String, Object>> last7Days() {
        String sql = "SELECT date, COUNT(*) AS cnt FROM attendance " +
                     "WHERE date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) " +
                     "GROUP BY date ORDER BY date ASC";
        List<Map<String, Object>> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                java.sql.Date d = rs.getDate("date");
                row.put("date", d != null ? d.toString() : "");
                row.put("count", rs.getInt("cnt"));
                list.add(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return list;
    }

    public List<Map<String, Object>> findTodayAbnormal() {
        String sql = "SELECT a.id, a.employee_id, a.check_in, a.date, e.name AS emp_name " +
                     "FROM attendance a LEFT JOIN employees e ON e.id = a.employee_id " +
                     "WHERE a.date = CURDATE() AND a.check_out IS NULL " +
                     "ORDER BY a.id DESC";
        List<Map<String, Object>> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("id", rs.getInt("id"));
                row.put("employeeId", rs.getInt("employee_id"));
                row.put("empName", rs.getString("emp_name"));
                row.put("checkIn", rs.getTimestamp("check_in"));
                list.add(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return list;
    }

    public int forceCheckOut(int recordId) {
        String sql = "UPDATE attendance SET check_out = ? WHERE id = ? AND check_out IS NULL";
        Connection conn = null;
        PreparedStatement pstmt = null;
        int result = 0;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
            pstmt.setInt(2, recordId);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt);
        }
        return result;
    }

    public int deleteById(int recordId) {
        String sql = "DELETE FROM attendance WHERE id = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        int result = 0;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, recordId);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt);
        }
        return result;
    }
}