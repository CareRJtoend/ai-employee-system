package com.employee.util;

import javax.servlet.http.HttpServletRequest;

/**
 * Web 通用工具
 */
public class WebUtil {

    /** 获取客户端真实 IP（兼容反向代理） */
    public static String getClientIp(HttpServletRequest req) {
        String ip = req.getHeader("X-Forwarded-For");
        if (isValid(ip)) {
            // X-Forwarded-For 可能是 "client, proxy1, proxy2"
            int comma = ip.indexOf(',');
            return comma > 0 ? ip.substring(0, comma).trim() : ip.trim();
        }
        ip = req.getHeader("X-Real-IP");
        if (isValid(ip)) {
            return ip.trim();
        }
        return req.getRemoteAddr();
    }

    private static boolean isValid(String ip) {
        return ip != null && !ip.isEmpty() && !"unknown".equalsIgnoreCase(ip);
    }
}