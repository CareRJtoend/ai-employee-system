package com.employee.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * 一次性把 users 表中的明文密码迁移为 BCrypt 哈希。
 * 已是 BCrypt（以 $2 开头）的记录会跳过，可重复执行。
 */
public class PasswordMigrator {

    public static void main(String[] args) {
        List<Object[]> toUpdate = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection()) {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT id, password FROM users");
            while (rs.next()) {
                int id = rs.getInt("id");
                String pwd = rs.getString("password");
                if (pwd != null && !PasswordUtil.isEncoded(pwd)) {
                    toUpdate.add(new Object[]{PasswordUtil.hash(pwd), id});
                }
            }
            rs.close();
            st.close();

            if (toUpdate.isEmpty()) {
                System.out.println("无需迁移，所有密码已是 BCrypt。");
                return;
            }

            try (PreparedStatement up = conn.prepareStatement("UPDATE users SET password = ? WHERE id = ?")) {
                for (Object[] row : toUpdate) {
                    up.setString(1, (String) row[0]);
                    up.setInt(2, (Integer) row[1]);
                    up.addBatch();
                }
                up.executeBatch();
            }
            System.out.println("迁移完成，共处理 " + toUpdate.size() + " 条明文密码。");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}