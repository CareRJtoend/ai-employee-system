package com.employee.dao;

import com.employee.entity.User;
import com.employee.util.DBUtil;
import com.employee.util.PasswordUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

public class UserDao {

    /** 按用户名查询（用于登录时先取出用户做状态/密码校验） */
    public User findByUsername(String username) {
        String sql = "SELECT * FROM users WHERE username = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        User user = null;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                user = mapRow(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return user;
    }

    public boolean isUsernameExists(String username) {
        String sql = "SELECT 1 FROM users WHERE username = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            rs = pstmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return false;
    }

    /** 注册：密码自动 BCrypt 哈希后存库 */
    public boolean register(String username, String rawPassword) {
        String sql = "INSERT INTO users (username, password, role) VALUES (?, ?, 'user')";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, PasswordUtil.hash(rawPassword));
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt);
        }
        return false;
    }

    /** 登录失败：累加失败次数，必要时写入锁定截止时间 */
    public void updateAfterFailedLogin(int id, int failedCount, LocalDateTime lockUntil) {
        String sql = "UPDATE users SET failed_count = ?, lock_until = ? WHERE id = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, failedCount);
            pstmt.setTimestamp(2, lockUntil == null ? null : Timestamp.valueOf(lockUntil));
            pstmt.setInt(3, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt);
        }
    }

    /** 登录成功：清零失败次数、解除锁定、记录登录时间/IP */
    public void updateAfterSuccessLogin(int id, LocalDateTime loginTime, String ip) {
        String sql = "UPDATE users SET failed_count = 0, lock_until = NULL, last_login_time = ?, last_login_ip = ? WHERE id = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setTimestamp(1, Timestamp.valueOf(loginTime));
            pstmt.setString(2, ip);
            pstmt.setInt(3, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt);
        }
    }

    private User mapRow(ResultSet rs) throws SQLException {
        User user = new User();
        user.setId(rs.getInt("id"));
        user.setUsername(rs.getString("username"));
        user.setPassword(rs.getString("password"));
        user.setRole(rs.getString("role"));
        user.setFailedCount(rs.getInt("failed_count"));
        Timestamp lockUntil = rs.getTimestamp("lock_until");
        user.setLockUntil(lockUntil == null ? null : lockUntil.toLocalDateTime());
        Timestamp lastLogin = rs.getTimestamp("last_login_time");
        user.setLastLoginTime(lastLogin == null ? null : lastLogin.toLocalDateTime());
        user.setLastLoginIp(rs.getString("last_login_ip"));
        return user;
    }
}