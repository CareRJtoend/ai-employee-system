package com.employee.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * AI 对话服务：调用智谱 GLM-4-Flash（免费）开放接口。
 * 仅使用 JDK 自带的 HttpURLConnection，手动构建/解析 JSON，不引入任何第三方依赖。
 */
public class AIService {

    /** 智谱开放接口地址 */
    private static final String API_URL = "https://open.bigmodel.cn/api/paas/v4/chat/completions";

    /**
     * API Key 从系统环境变量 ZHIPU_API_KEY 读取，代码里不再硬编码真实密钥。
     * 若未配置则回退为占位符，方便他人知道这里需要填 Key。
     */
    private static final String API_KEY = System.getenv("ZHIPU_API_KEY") != null
            ? System.getenv("ZHIPU_API_KEY")
            : "请在此处填入你的智谱API_KEY";

    /** 使用的模型：glm-4-flash 完全免费 */
    private static final String MODEL = "glm-4-flash";

    /** 默认系统人设 */
    private static final String SYSTEM_PROMPT = "你是一个员工管理系统的智能助手";

    private static final int CONNECT_TIMEOUT = 10000;
    private static final int READ_TIMEOUT = 60000;

    /** 出错或无内容时返回的友好提示 */
    private static final String FALLBACK_MSG = "AI 服务暂时不可用，请稍后再试。";

    /**
     * 单轮对话：输入用户问题，返回 AI 回答。
     */
    public String chat(String userMessage) {
        List<Map<String, String>> messages = new ArrayList<>();
        messages.add(buildMessage("system", SYSTEM_PROMPT));
        messages.add(buildMessage("user", userMessage == null ? "" : userMessage));
        return chatWithContext(messages);
    }

    /**
     * 多轮对话：调用方自行组织完整上下文。
     * 每个 Map 形如 {"role": "user", "content": "..."}，
     * role 可为 system / user / assistant。
     * 若列表中不含 system 消息，会自动补上默认人设。
     */
    public String chatWithContext(List<Map<String, String>> messages) {
        if (messages == null || messages.isEmpty()) {
            return FALLBACK_MSG;
        }
        if ("请在此处填入你的智谱API_KEY".equals(API_KEY)) {
            System.err.println("未检测到环境变量 ZHIPU_API_KEY，AI 对话功能不可用。");
            return FALLBACK_MSG;
        }
        try {
            List<Map<String, String>> fullMessages = ensureSystemPrompt(messages);
            String requestBody = buildRequestBody(fullMessages);
            String response = post(requestBody);
            String content = extractContent(response);
            return (content == null || content.isEmpty()) ? FALLBACK_MSG : content;
        } catch (Exception e) {
            System.err.println("AIService 调用失败: " + e.getMessage());
            return FALLBACK_MSG;
        }
    }

    // ==================== 内部方法 ====================

    /** 没有 system 人设时自动补一个在最前面 */
    private List<Map<String, String>> ensureSystemPrompt(List<Map<String, String>> messages) {
        for (Map<String, String> m : messages) {
            if ("system".equals(m.get("role"))) {
                return messages;
            }
        }
        List<Map<String, String>> result = new ArrayList<>();
        result.add(buildMessage("system", SYSTEM_PROMPT));
        result.addAll(messages);
        return result;
    }

    private Map<String, String> buildMessage(String role, String content) {
        Map<String, String> msg = new java.util.HashMap<>();
        msg.put("role", role);
        msg.put("content", content);
        return msg;
    }

    /** 手动拼接 OpenAI 兼容格式的请求体 JSON */
    private String buildRequestBody(List<Map<String, String>> messages) {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append("\"model\":\"").append(MODEL).append("\",")
                .append("\"messages\":[");
        for (int i = 0; i < messages.size(); i++) {
            Map<String, String> m = messages.get(i);
            sb.append("{\"role\":\"").append(escapeJson(m.get("role")))
                    .append("\",\"content\":\"").append(escapeJson(m.get("content")))
                    .append("\"}");
            if (i < messages.size() - 1) {
                sb.append(",");
            }
        }
        sb.append("]}");
        return sb.toString();
    }

    /** 发送 POST 请求并读取响应体 */
    private String post(String jsonBody) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(API_URL).openConnection();
        try {
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(CONNECT_TIMEOUT);
            conn.setReadTimeout(READ_TIMEOUT);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + API_KEY);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(jsonBody.getBytes(StandardCharsets.UTF_8));
            }

            int status = conn.getResponseCode();
            InputStream is = (status >= 200 && status < 300)
                    ? conn.getInputStream() : conn.getErrorStream();
            String body = readAll(is);

            if (status != 200) {
                throw new RuntimeException("HTTP " + status + ": " + body);
            }
            return body;
        } finally {
            conn.disconnect();
        }
    }

    private String readAll(InputStream is) throws Exception {
        if (is == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        }
        return sb.toString();
    }

    /**
     * 从响应 JSON 中提取 choices[0].message.content。
     * 定位 "message" 之后的第一个完整字符串值即为回答内容。
     */
    private String extractContent(String json) {
        if (json == null || json.isEmpty()) {
            return null;
        }
        int msgIdx = json.indexOf("\"message\"");
        if (msgIdx < 0) {
            return null;
        }
        int colonIdx = json.indexOf(':', msgIdx + 9);
        if (colonIdx < 0) {
            return null;
        }
        int braceIdx = json.indexOf('{', colonIdx);
        int contentKeyIdx = json.indexOf("\"content\"", braceIdx);
        if (contentKeyIdx < 0) {
            return null;
        }
        int contentColon = json.indexOf(':', contentKeyIdx + 9);
        if (contentColon < 0) {
            return null;
        }
        int quoteIdx = json.indexOf('"', contentColon + 1);
        if (quoteIdx < 0) {
            return null;
        }
        return readJsonString(json, quoteIdx);
    }

    /**
     * 从 start 处的引号开始读取一个完整 JSON 字符串值，
     * 正确处理引号、反斜杠、换行以及 \\uXXXX 等转义，返回反转义后的明文。
     */
    private String readJsonString(String s, int startQuote) {
        StringBuilder out = new StringBuilder();
        int i = startQuote + 1;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '\\') {
                if (i + 1 >= s.length()) {
                    break;
                }
                char n = s.charAt(i + 1);
                switch (n) {
                    case 'n': out.append('\n'); break;
                    case 't': out.append('\t'); break;
                    case 'r': out.append('\r'); break;
                    case 'b': out.append('\b'); break;
                    case 'f': out.append('\f'); break;
                    case '"': out.append('"'); break;
                    case '\\': out.append('\\'); break;
                    case '/': out.append('/'); break;
                    case 'u':
                        if (i + 5 < s.length()) {
                            out.append((char) Integer.parseInt(s.substring(i + 2, i + 6), 16));
                            i += 4;
                        }
                        break;
                    default: out.append(n); break;
                }
                i += 2;
            } else if (c == '"') {
                break;
            } else {
                out.append(c);
                i++;
            }
        }
        return out.toString();
    }

    /** JSON 字符串值转义 */
    private String escapeJson(String raw) {
        if (raw == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        return sb.toString();
    }
}