package com.employee.entity;

public class Department {

    private int id;
    private String name;
    private String manager;
    private String description;

    public Department() {
    }

    public Department(int id, String name, String manager, String description) {
        this.id = id;
        this.name = name;
        this.manager = manager;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}