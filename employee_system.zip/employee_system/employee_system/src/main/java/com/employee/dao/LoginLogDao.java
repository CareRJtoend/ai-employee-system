package com.employee.dao;

import com.employee.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class LoginLogDao {

    public void log(String username, String ip, boolean success, String message) {
        String sql = "INSERT INTO login_log (username, ip, success, message) VALUES (?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, ip);
            pstmt.setInt(3, success ? 1 : 0);
            pstmt.setString(4, message);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt);
        }
    }
}