package com.employee.dao;

import com.employee.entity.Employee;
import com.employee.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class EmployeeDao {

    public List<Employee> findAll() {
        String sql = "SELECT * FROM employees";
        List<Employee> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return list;
    }

    public Employee findById(int id) {
        String sql = "SELECT * FROM employees WHERE id = ?";
        Employee emp = null;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                emp = mapRow(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return emp;
    }

    public List<Employee> search(String keyword) {
        String sql = "SELECT * FROM employees WHERE name LIKE ? OR phone LIKE ? OR email LIKE ?";
        List<Employee> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            String pattern = "%" + keyword + "%";
            pstmt.setString(1, pattern);
            pstmt.setString(2, pattern);
            pstmt.setString(3, pattern);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return list;
    }

    public int insert(Employee employee) {
        String sql = "INSERT INTO employees (name, gender, phone, email, dept_id, position, hire_date) VALUES (?, ?, ?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;
        int result = 0;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, employee.getName());
            pstmt.setString(2, employee.getGender());
            pstmt.setString(3, employee.getPhone());
            pstmt.setString(4, employee.getEmail());
            pstmt.setInt(5, employee.getDeptId());
            pstmt.setString(6, employee.getPosition());
            pstmt.setDate(7, employee.getHireDate() != null ? new java.sql.Date(employee.getHireDate().getTime()) : null);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt);
        }
        return result;
    }

    public int update(Employee employee) {
        String sql = "UPDATE employees SET name = ?, gender = ?, phone = ?, email = ?, dept_id = ?, position = ?, hire_date = ? WHERE id = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        int result = 0;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, employee.getName());
            pstmt.setString(2, employee.getGender());
            pstmt.setString(3, employee.getPhone());
            pstmt.setString(4, employee.getEmail());
            pstmt.setInt(5, employee.getDeptId());
            pstmt.setString(6, employee.getPosition());
            pstmt.setDate(7, employee.getHireDate() != null ? new java.sql.Date(employee.getHireDate().getTime()) : null);
            pstmt.setInt(8, employee.getId());
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt);
        }
        return result;
    }

    public int delete(int id) {
        String sql = "DELETE FROM employees WHERE id = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        int result = 0;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt);
        }
        return result;
    }

    private Employee mapRow(ResultSet rs) throws SQLException {
        Employee emp = new Employee();
        emp.setId(rs.getInt("id"));
        emp.setName(rs.getString("name"));
        emp.setGender(rs.getString("gender"));
        emp.setPhone(rs.getString("phone"));
        emp.setEmail(rs.getString("email"));
        emp.setDeptId(rs.getInt("dept_id"));
        emp.setPosition(rs.getString("position"));
        emp.setHireDate(rs.getDate("hire_date"));
        return emp;
    }

    public int countAll() {
        String sql = "SELECT COUNT(*) FROM employees";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int count = 0;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return count;
    }

    public List<Map<String, Object>> countGroupByDept() {
        String sql = "SELECT d.name AS dept_name, COUNT(e.id) AS emp_count " +
                     "FROM departments d LEFT JOIN employees e ON e.dept_id = d.id " +
                     "GROUP BY d.id, d.name ORDER BY emp_count DESC";
        List<Map<String, Object>> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("name", rs.getString("dept_name"));
                row.put("value", rs.getInt("emp_count"));
                list.add(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return list;
    }

    public List<Map<String, Object>> findRecentHired(int limit) {
        String sql = "SELECT e.name, e.gender, e.position, e.hire_date, d.name AS dept_name " +
                     "FROM employees e LEFT JOIN departments d ON e.dept_id = d.id " +
                     "ORDER BY e.hire_date DESC LIMIT ?";
        List<Map<String, Object>> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, limit);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("name", rs.getString("name"));
                row.put("gender", rs.getString("gender"));
                row.put("position", rs.getString("position"));
                row.put("deptName", rs.getString("dept_name"));
                java.sql.Date hd = rs.getDate("hire_date");
                row.put("hireDate", hd != null ? hd.toString() : "");
                list.add(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return list;
    }
}