package com.employee.filter;

import com.employee.entity.User;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * 游客只读拦截器：role=guest 仅可浏览，禁止任何写操作/交互。
 */
@WebFilter({"/employee", "/department", "/attendance"})
public class GuestReadonlyFilter implements Filter {

    /** 考勤中仅这几个动作是「查看」，其余（签到/签退/补签/记迟到/代签退/删除）都拦截 */
    private static final Set<String> VIEW_ONLY_ACTIONS = new HashSet<>(Arrays.asList("", "list", "myRecords"));

    @Override
    public void doFilter(ServletRequest sreq, ServletResponse sresp, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) sreq;
        HttpServletResponse resp = (HttpServletResponse) sresp;

        HttpSession session = req.getSession(false);
        User user = session == null ? null : (User) session.getAttribute("loginUser");

        // 非游客（admin / user）不受本拦截器约束
        if (user == null || !"guest".equalsIgnoreCase(user.getRole())) {
            chain.doFilter(sreq, sresp);
            return;
        }

        String path = req.getRequestURI().substring(req.getContextPath().length());

        // 游客不可进入员工 / 部门管理
        if (path.startsWith("/employee") || path.startsWith("/department")) {
            deny(req, resp);
            return;
        }

        // 考勤：只允许查看，拦截所有写操作
        String action = req.getParameter("action");
        if (action == null) {
            action = "";
        }
        if (!VIEW_ONLY_ACTIONS.contains(action)) {
            deny(req, resp);
            return;
        }

        chain.doFilter(sreq, sresp);
    }

    private void deny(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("errorMsg", "游客模式仅可浏览，不能执行该操作");
        req.getRequestDispatcher("/error/403.jsp").forward(req, resp);
    }
}