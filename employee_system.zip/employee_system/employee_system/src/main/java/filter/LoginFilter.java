package com.employee.filter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * 登录校验拦截器：未登录统一拦截，白名单放行。
 */
@WebFilter("/*")
public class LoginFilter implements Filter {

    @Override
    public void doFilter(ServletRequest sreq, ServletResponse sresp, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) sreq;
        HttpServletResponse resp = (HttpServletResponse) sresp;

        String context = req.getContextPath();
        String path = req.getRequestURI().substring(context.length());

        if (isPublic(path)) {
            chain.doFilter(sreq, sresp);
            return;
        }

        HttpSession session = req.getSession(false);
        boolean logged = session != null && session.getAttribute("loginUser") != null;
        if (logged) {
            chain.doFilter(sreq, sresp);
            return;
        }

        // 未登录：接口返回 401 JSON，其余重定向登录页
        if (path.startsWith("/api/")) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            resp.setContentType("application/json;charset=UTF-8");
            resp.getWriter().write("{\"error\":\"未登录\"}");
            return;
        }
        resp.sendRedirect(context + "/login");
    }

    private boolean isPublic(String path) {
        return path.startsWith("/assets/")
                || path.startsWith("/error/")
                || path.equals("/login") || path.equals("/login.jsp")
                || path.equals("/register") || path.equals("/register.jsp")
                || path.equals("/captcha")
                || path.equals("/logout");
    }
}