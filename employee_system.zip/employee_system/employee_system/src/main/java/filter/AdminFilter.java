package com.employee.filter;

import com.employee.entity.User;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * 管理员权限拦截器：保护员工/部门相关 Servlet 与 JSP 直连访问。
 */
@WebFilter({
        "/employee", "/department",
        "/employee_list.jsp", "/employee_add.jsp", "/employee_edit.jsp",
        "/department_list.jsp", "/department_add.jsp", "/department_edit.jsp"
})
public class AdminFilter implements Filter {

    @Override
    public void doFilter(ServletRequest sreq, ServletResponse sresp, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) sreq;
        HttpServletResponse resp = (HttpServletResponse) sresp;

        HttpSession session = req.getSession(false);
        User user = session == null ? null : (User) session.getAttribute("loginUser");

        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }
        if (!"admin".equalsIgnoreCase(user.getRole())) {
            req.setAttribute("errorMsg", "该功能仅限管理员访问");
            req.getRequestDispatcher("/error/403.jsp").forward(req, resp);
            return;
        }
        chain.doFilter(sreq, sresp);
    }
}