<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录 · 智能员工管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --brand-1: #1e3c72;
            --brand-2: #2a5298;
            --brand-3: #6a11cb;
            --text-dark: #1a1f36;
            --text-muted: #6b7280;
            --border: #e5e7eb;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Segoe UI", "PingFang SC", "Microsoft YaHei", system-ui, sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #eef1f6;
            padding: 24px;
        }

        .shell {
            display: flex;
            width: 100%;
            max-width: 1000px;
            min-height: 620px;
            background: #fff;
            border-radius: 24px;
            overflow: hidden;
            box-shadow: 0 24px 60px -20px rgba(30, 60, 114, 0.45);
            animation: enter 0.7s cubic-bezier(0.16, 1, 0.3, 1) both;
        }

        @keyframes enter {
            from { opacity: 0; transform: translateY(24px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        /* ===== 左侧品牌区 ===== */
        .brand {
            position: relative;
            flex: 1 1 46%;
            padding: 56px 48px;
            background: linear-gradient(150deg, var(--brand-1) 0%, var(--brand-2) 45%, var(--brand-3) 100%);
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            overflow: hidden;
        }

        .brand::before,
        .brand::after {
            content: "";
            position: absolute;
            border-radius: 50%;
            filter: blur(2px);
        }

        .brand::before {
            width: 320px;
            height: 320px;
            top: -120px;
            right: -100px;
            background: radial-gradient(circle, rgba(255,255,255,0.14), transparent 70%);
        }

        .brand::after {
            width: 260px;
            height: 260px;
            bottom: -80px;
            left: -70px;
            background: radial-gradient(circle, rgba(255,255,255,0.10), transparent 70%);
        }

        .brand-grid {
            position: absolute;
            inset: 0;
            background-image:
                linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px);
            background-size: 44px 44px;
            mask-image: radial-gradient(circle at 30% 20%, #000 0%, transparent 75%);
            -webkit-mask-image: radial-gradient(circle at 30% 20%, #000 0%, transparent 75%);
            pointer-events: none;
        }

        .brand > * { position: relative; z-index: 1; }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-mark {
            width: 46px;
            height: 46px;
            border-radius: 13px;
            background: rgba(255,255,255,0.16);
            border: 1px solid rgba(255,255,255,0.28);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .logo-mark svg { width: 26px; height: 26px; }

        .logo-text {
            font-size: 1.05rem;
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .brand-copy h1 {
            font-size: 2.1rem;
            font-weight: 700;
            line-height: 1.3;
            margin-bottom: 14px;
        }

        .brand-copy p {
            font-size: 0.95rem;
            line-height: 1.8;
            color: rgba(255,255,255,0.78);
            max-width: 320px;
        }

        .features {
            margin-top: 34px;
            display: flex;
            flex-direction: column;
            gap: 18px;
        }

        .feature {
            display: flex;
            align-items: center;
            gap: 14px;
            font-size: 0.92rem;
            color: rgba(255,255,255,0.92);
        }

        .feature i {
            width: 38px;
            height: 38px;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
            background: rgba(255,255,255,0.14);
            border: 1px solid rgba(255,255,255,0.18);
            font-size: 1.05rem;
        }

        .brand-foot {
            font-size: 0.8rem;
            color: rgba(255,255,255,0.55);
        }

        /* ===== 右侧表单区 ===== */
        .form-side {
            flex: 1 1 54%;
            padding: 56px 60px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .form-head h2 {
            font-size: 1.7rem;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: 8px;
        }

        .form-head p {
            color: var(--text-muted);
            font-size: 0.92rem;
            margin-bottom: 30px;
        }

        .field { margin-bottom: 20px; }

        .field label {
            display: block;
            font-size: 0.85rem;
            font-weight: 600;
            color: #374151;
            margin-bottom: 8px;
        }

        .input-wrap {
            position: relative;
            display: flex;
            align-items: center;
        }

        .input-wrap > i.lead {
            position: absolute;
            left: 16px;
            color: #9ca3af;
            font-size: 1.05rem;
            transition: color 0.25s;
        }

        .input-wrap input {
            width: 100%;
            padding: 14px 16px 14px 46px;
            border: 1.5px solid var(--border);
            border-radius: 12px;
            font-size: 0.95rem;
            color: var(--text-dark);
            background: #fafbfc;
            outline: none;
            transition: all 0.25s;
        }

        .input-wrap input::placeholder { color: #b0b6c0; }

        .input-wrap input:focus {
            background: #fff;
            border-color: var(--brand-2);
            box-shadow: 0 0 0 4px rgba(42, 82, 152, 0.12);
        }

        .input-wrap:focus-within > i.lead { color: var(--brand-2); }

        .toggle-pwd {
            position: absolute;
            right: 14px;
            background: none;
            border: none;
            color: #9ca3af;
            cursor: pointer;
            font-size: 1.05rem;
            padding: 4px;
            transition: color 0.2s;
        }

        .toggle-pwd:hover { color: var(--brand-2); }

        .err-msg {
            color: #dc2626;
            font-size: 0.78rem;
            margin-top: 6px;
            min-height: 1em;
        }

        .options {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin: 4px 0 26px;
        }

        .remember {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.86rem;
            color: #4b5563;
            cursor: pointer;
        }

        .remember input {
            width: 16px;
            height: 16px;
            accent-color: var(--brand-2);
            cursor: pointer;
        }

        .link {
            font-size: 0.86rem;
            color: var(--brand-2);
            text-decoration: none;
            font-weight: 500;
        }

        .link:hover { text-decoration: underline; }

        .btn-login {
            position: relative;
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 12px;
            background: linear-gradient(135deg, var(--brand-2) 0%, var(--brand-3) 100%);
            color: #fff;
            font-size: 1rem;
            font-weight: 600;
            letter-spacing: 1px;
            cursor: pointer;
            overflow: hidden;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            box-shadow: 0 6px 18px rgba(42, 82, 152, 0.3);
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 26px rgba(106, 17, 203, 0.38);
        }

        .btn-login:active { transform: translateY(0); }

        .btn-login .ripple {
            position: absolute;
            border-radius: 50%;
            background: rgba(255,255,255,0.45);
            transform: scale(0);
            animation: ripple 0.6s linear;
            pointer-events: none;
        }

        @keyframes ripple { to { transform: scale(4); opacity: 0; } }

        .btn-login:disabled {
            opacity: 0.7;
            cursor: not-allowed;
            transform: none;
        }

        .btn-guest {
            width: 100%;
            margin-top: 14px;
            padding: 13px;
            border: 1.5px solid var(--border);
            border-radius: 12px;
            background: #fff;
            color: #4b5563;
            font-size: 0.92rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
        }

        .btn-guest:hover {
            border-color: #c7ccd6;
            background: #f7f8fa;
            color: var(--text-dark);
        }

        .signup {
            text-align: center;
            margin-top: 28px;
            font-size: 0.88rem;
            color: var(--text-muted);
        }

        .alert-err {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #dc2626;
            border-radius: 10px;
            padding: 11px 14px;
            font-size: 0.87rem;
            margin-bottom: 22px;
            animation: shake 0.4s ease;
        }

        @keyframes shake {
            0%,100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }

        /* ===== 响应式 ===== */
        @media (max-width: 860px) {
            body { padding: 0; align-items: stretch; }
            .shell {
                flex-direction: column;
                max-width: 460px;
                min-height: auto;
                border-radius: 0;
                margin: auto;
            }
            .brand { padding: 40px 32px; flex: none; }
            .brand-copy h1 { font-size: 1.6rem; }
            .features { display: none; }
            .brand-foot { display: none; }
            .form-side { padding: 40px 32px; }
        }
    </style>
</head>
<body>
    <div class="shell">
        <!-- 左侧品牌区 -->
        <div class="brand">
            <div class="brand-grid"></div>

            <div class="logo">
                <div class="logo-mark">
                    <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8"
                         stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="9" cy="7" r="3"/>
                        <path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/>
                        <path d="M16 4.5a3 3 0 0 1 0 5.6"/>
                        <path d="M18 14c2 .8 3.4 2.7 3.4 5"/>
                    </svg>
                </div>
                <span class="logo-text">智能员工管理系统</span>
            </div>

            <div class="brand-copy">
                <h1>让团队管理<br>更简单、更高效</h1>
                <p>AI-Powered Employee Management<br>一站式员工档案、考勤与部门协同平台。</p>
                <div class="features">
                    <div class="feature"><i class="bi bi-shield-check"></i><span>企业级数据安全保障</span></div>
                    <div class="feature"><i class="bi bi-graph-up-arrow"></i><span>智能考勤与绩效分析</span></div>
                    <div class="feature"><i class="bi bi-people"></i><span>多部门高效协同管理</span></div>
                </div>
            </div>

            <div class="brand-foot">© 2026 Employee System · 保留所有权利</div>
        </div>

        <!-- 右侧表单区 -->
        <div class="form-side">
            <div class="form-head">
                <h2>欢迎回来</h2>
                <p>请登录您的账号以继续使用系统</p>
            </div>

            <c:if test="${not empty error}">
                <div class="alert-err">
                    <i class="bi bi-exclamation-circle-fill"></i><span>${error}</span>
                </div>
            </c:if>

            <c:if test="${not empty success}">
                <div style="display:flex;align-items:center;gap:8px;background:#f0fdf4;border:1px solid #bbf7d0;color:#16a34a;border-radius:10px;padding:11px 14px;font-size:0.87rem;margin-bottom:22px;">
                    <i class="bi bi-check-circle-fill"></i><span>${success}</span>
                </div>
            </c:if>

            <form action="${pageContext.request.contextPath}/login" method="post" id="loginForm" novalidate>
                <div class="field">
                    <label for="username">用户名</label>
                    <div class="input-wrap">
                        <i class="bi bi-person lead"></i>
                        <input type="text" id="username" name="username"
                               placeholder="请输入用户名" autocomplete="username" required>
                    </div>
                    <div class="err-msg" id="errUsername"></div>
                </div>

                <div class="field">
                    <label for="password">密码</label>
                    <div class="input-wrap">
                        <i class="bi bi-lock lead"></i>
                        <input type="password" id="password" name="password"
                               placeholder="请输入密码" autocomplete="current-password" required>
                        <button type="button" class="toggle-pwd" onclick="togglePassword()" aria-label="显示密码">
                            <i class="bi bi-eye" id="eyeIcon"></i>
                        </button>
                    </div>
                    <div class="err-msg" id="errPassword"></div>
                </div>

                <div class="field">
                    <label for="captcha">验证码</label>
                    <div class="input-wrap">
                        <i class="bi bi-shield-lock lead"></i>
                        <input type="text" id="captcha" name="captcha"
                               placeholder="请输入右侧验证码" autocomplete="off" maxlength="4"
                               required style="padding-right:126px;">
                        <img id="captchaImg"
                             src="${pageContext.request.contextPath}/captcha"
                             alt="验证码" title="看不清？点击刷新"
                             onclick="this.src='${pageContext.request.contextPath}/captcha?t=' + new Date().getTime()"
                             style="position:absolute;right:8px;top:50%;transform:translateY(-50%);height:38px;width:112px;border-radius:8px;cursor:pointer;border:1px solid #e5e7eb;">
                    </div>
                    <div class="err-msg" id="errCaptcha"></div>
                </div>

                <div class="options">
                    <label class="remember">
                        <input type="checkbox" name="remember"> <span>记住我</span>
                    </label>
                    <a href="javascript:void(0)" class="link" onclick="alert('如忘记密码，请联系系统管理员协助重置')">忘记密码？</a>
                </div>

                <button type="submit" class="btn-login" id="loginBtn">
                    <span class="btn-text">登 录</span>
                </button>

                <button type="button" class="btn-guest" onclick="guestLogin()">
                    <i class="bi bi-person-badge me-1"></i>游客登录
                </button>
            </form>

            <div style="margin-top:14px; padding:10px 14px; border-radius:10px; background:rgba(30,60,114,0.05); border:1px dashed rgba(30,60,114,0.25); font-size:0.78rem; color:#5a6472; display:flex; flex-direction:column; gap:4px;">
                <div><i class="bi bi-shield-fill-check me-1" style="color:#6a11cb;"></i>管理员：员工 / 部门 / 考勤全部管理权限</div>
                <div><i class="bi bi-person-fill me-1" style="color:#2a5298;"></i>普通用户：数据看板 + 考勤签到 / 记录查看</div>
            </div>

            <div class="signup">
                还没有账号？<a href="${pageContext.request.contextPath}/register" class="link">立即注册</a>
            </div>
        </div>
    </div>

    <script>
        var loginForm = document.getElementById('loginForm');
        var loginBtn = document.getElementById('loginBtn');

        loginForm.addEventListener('submit', function (e) {
            var u = document.getElementById('username');
            var p = document.getElementById('password');
            var cap = document.getElementById('captcha');
            var eu = document.getElementById('errUsername');
            var ep = document.getElementById('errPassword');
            var ec = document.getElementById('errCaptcha');
            eu.textContent = ''; ep.textContent = ''; ec.textContent = '';
            var ok = true;

            if (!u.value.trim()) { eu.textContent = '用户名不能为空'; ok = false; }
            if (!p.value) { ep.textContent = '密码不能为空'; ok = false; }
            else if (p.value.length < 4) { ep.textContent = '密码长度至少 4 位'; ok = false; }
            if (!cap.value.trim()) { ec.textContent = '请输入验证码'; ok = false; }

            if (!ok) { e.preventDefault(); return; }

            loginBtn.disabled = true;
            loginBtn.querySelector('.btn-text').textContent = '登录中…';
        });

        document.getElementById('loginBtn').addEventListener('click', function (e) {
            var btn = this;
            var ripple = document.createElement('span');
            ripple.className = 'ripple';
            var rect = btn.getBoundingClientRect();
            var size = Math.max(rect.width, rect.height);
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
            ripple.style.top = (e.clientY - rect.top - size / 2) + 'px';
            btn.appendChild(ripple);
            setTimeout(function () { ripple.remove(); }, 600);
        });

        function togglePassword() {
            const pwd = document.getElementById('password');
            const icon = document.getElementById('eyeIcon');
            if (pwd.type === 'password') {
                pwd.type = 'text';
                icon.className = 'bi bi-eye-slash';
            } else {
                pwd.type = 'password';
                icon.className = 'bi bi-eye';
            }
        }

        function guestLogin() {
            document.getElementById('username').value = 'guest';
            document.getElementById('password').value = 'guest123';
            var cap = document.getElementById('captcha');
            if (cap) { cap.focus(); }
        }
    </script>
</body>
</html>