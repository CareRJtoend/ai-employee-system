<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>个人考勤 - 员工管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { overflow: hidden; }
        .sidebar { width: 240px; min-height: 100vh; background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%); position: fixed; left: 0; top: 0; z-index: 100; }
        .sidebar .brand { padding: 1.2rem 1rem; color: #fff; font-size: 1.2rem; font-weight: bold; border-bottom: 1px solid rgba(255,255,255,0.1); text-align: center; }
        .sidebar .nav-link { color: rgba(255,255,255,0.7); padding: 0.8rem 1.2rem; border-radius: 8px; margin: 4px 10px; transition: all 0.2s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { color: #fff; background: rgba(255,255,255,0.1); }
        .sidebar .nav-link i { margin-right: 10px; width: 20px; text-align: center; }
        .main-content { margin-left: 240px; min-height: 100vh; background: #f0f2f5; }
        .top-bar { background: #fff; padding: 0.8rem 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.05); display: flex; justify-content: space-between; align-items: center; }
        .content-area { padding: 2rem; }
        .table-card { border: none; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="brand"><i class="bi bi-building me-2"></i>员工管理系统</div>
        <ul class="nav flex-column mt-3">
            <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/index.jsp"><i class="bi bi-house-door"></i>首页</a></li>
            <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/employee"><i class="bi bi-people"></i>员工管理</a></li>
            <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/department"><i class="bi bi-diagram-3"></i>部门管理</a></li>
            <li class="nav-item"><a class="nav-link active" href="${pageContext.request.contextPath}/attendance"><i class="bi bi-calendar-check"></i>考勤管理</a></li>
            <li class="nav-item mt-4"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i>退出登录</a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="top-bar">
            <h5 class="mb-0">个人考勤 - ${employee.name}</h5>
            <a href="${pageContext.request.contextPath}/attendance" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-arrow-left me-1"></i>返回
            </a>
        </div>
        <div class="content-area">
            <div class="card table-card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th><th>签到时间</th><th>签退时间</th><th>日期</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:choose>
                                    <c:when test="${not empty records}">
                                        <c:forEach var="rec" items="${records}">
                                            <tr>
                                                <td>${rec.id}</td>
                                                <td><fmt:formatDate value="${rec.checkIn}" pattern="yyyy-MM-dd HH:mm:ss"/></td>
                                                <td>
                                                    <c:choose>
                                                        <c:when test="${rec.checkOut != null}">
                                                            <fmt:formatDate value="${rec.checkOut}" pattern="yyyy-MM-dd HH:mm:ss"/>
                                                        </c:when>
                                                        <c:otherwise>
                                                            <span class="badge bg-warning text-dark">未签退</span>
                                                        </c:otherwise>
                                                    </c:choose>
                                                </td>
                                                <td><fmt:formatDate value="${rec.date}" pattern="yyyy-MM-dd"/></td>
                                            </tr>
                                        </c:forEach>
                                    </c:when>
                                    <c:otherwise>
                                        <tr><td colspan="4" class="text-center text-muted py-4">暂无考勤记录</td></tr>
                                    </c:otherwise>
                                </c:choose>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>