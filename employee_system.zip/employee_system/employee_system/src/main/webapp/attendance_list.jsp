<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>考勤管理 · 智能员工管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="${pageContext.request.contextPath}/assets/css/app.css" rel="stylesheet">
</head>
<body>
<c:set var="activePage" value="attendance" scope="page"/>
<%@ include file="/includes/sidebar.jspf" %>

<div class="main-content">
    <div class="top-bar">
        <div class="welcome"><h4>考勤管理</h4><div class="date">签到 / 签退 / 补签 / 记迟到 / 异常处理</div></div>
        <span class="role-badge ${loginUser.role == 'admin' ? 'admin' : ''}"><i class="bi bi-shield-check"></i>${loginUser.role == 'admin' ? '管理员' : (loginUser.role == 'guest' ? '游客' : '普通用户')}</span>
    </div>

    <div class="content-area">
        <c:if test="${loginUser.role != 'guest'}">
            <div class="panel">
                <h5 class="panel-title">日常考勤</h5>
                <form class="toolbar" action="${pageContext.request.contextPath}/attendance" method="get" style="margin-bottom:0;">
                    <div class="toolbar-actions">
                        <input type="hidden" name="action" value="checkIn">
                        <input type="number" name="employeeId" class="form-input" style="width:130px;" placeholder="员工 ID" min="1" required>
                        <button class="btn-grad" style="background:linear-gradient(135deg,#10b981,#059669);"><i class="bi bi-box-arrow-in-right"></i>签到</button>
                    </div>
                    <div class="toolbar-actions">
                        <input type="hidden" name="action" value="checkOut">
                        <input type="number" name="employeeId" class="form-input" style="width:130px;" placeholder="员工 ID" min="1" required>
                        <button class="btn-grad" style="background:linear-gradient(135deg,#f97316,#ea580c);"><i class="bi bi-box-arrow-right"></i>签退</button>
                    </div>
                </form>
            </div>
        </c:if>

        <c:if test="${loginUser.role == 'admin'}">
            <div class="panel">
                <h5 class="panel-title">补签（管理员）</h5>
                <form class="toolbar" action="${pageContext.request.contextPath}/attendance" method="get" style="margin-bottom:0;">
                    <div class="toolbar-actions">
                        <input type="hidden" name="action" value="makeup">
                        <input type="number" name="employeeId" class="form-input" style="width:130px;" placeholder="员工 ID" min="1" required>
                        <input type="date" name="date" class="form-input" style="width:170px;" required>
                        <button class="btn-grad"><i class="bi bi-calendar-plus"></i>补签（按 09:00 记）</button>
                    </div>
                </form>
            </div>

            <div class="panel">
                <h5 class="panel-title">今日异常考勤处理 <span class="badge-soft err" style="margin-left:6px;">${fn:length(abnormalRecords)} 条待处理</span></h5>
                <div style="overflow-x:auto;">
                    <table class="table-dash">
                        <thead>
                            <tr><th>ID</th><th>员工</th><th>签到时间</th><th>状态</th><th style="text-align:right;">处理操作</th></tr>
                        </thead>
                        <tbody>
                            <c:choose>
                                <c:when test="${not empty abnormalRecords}">
                                    <c:forEach var="ab" items="${abnormalRecords}">
                                        <tr>
                                            <td>${ab.id}</td>
                                            <td><span class="avatar">${fn:substring(ab.empName, 0, 1)}</span>${ab.empName} <span class="tag">#${ab.employeeId}</span></td>
                                            <td><fmt:formatDate value="${ab.checkIn}" pattern="HH:mm:ss"/></td>
                                            <td><span class="badge-soft warn">未签退</span></td>
                                            <td style="text-align:right;white-space:nowrap;">
                                                <a class="btn-icon edit" title="代为签退" href="${pageContext.request.contextPath}/attendance?action=forceCheckOut&id=${ab.id}" onclick="return confirm('确定为该记录代为签退（当前时间）吗？');"><i class="bi bi-box-arrow-right"></i></a>
                                                <a class="btn-icon" title="记迟到" style="margin-left:6px;" href="${pageContext.request.contextPath}/attendance?action=markLate&id=${ab.id}" onclick="return confirm('确定将该记录记为迟到吗？');"><i class="bi bi-alarm"></i></a>
                                                <a class="btn-icon del" title="删除记录" style="margin-left:6px;" href="${pageContext.request.contextPath}/attendance?action=deleteRecord&id=${ab.id}" onclick="return confirm('删除后不可恢复，确定删除？');"><i class="bi bi-trash"></i></a>
                                            </td>
                                        </tr>
                                    </c:forEach>
                                </c:when>
                                <c:otherwise>
                                    <tr><td colspan="5" class="empty-row">今日暂无异常考勤 🎉</td></tr>
                                </c:otherwise>
                            </c:choose>
                        </tbody>
                    </table>
                </div>
            </div>
        </c:if>

        <div class="panel">
            <h5 class="panel-title">考勤记录</h5>
            <div style="overflow-x:auto;">
                <table class="table-dash">
                    <thead>
                        <tr>
                            <th>ID</th><th>员工 ID</th><th>签到</th><th>签退</th><th>状态</th><th>日期</th>
                            <c:if test="${loginUser.role == 'admin'}"><th style="text-align:right;">操作</th></c:if>
                        </tr>
                    </thead>
                    <tbody>
                        <c:choose>
                            <c:when test="${not empty records}">
                                <c:forEach var="rec" items="${records}">
                                    <tr>
                                        <td>${rec.id}</td>
                                        <td><span class="tag">#${rec.employeeId}</span></td>
                                        <td><fmt:formatDate value="${rec.checkIn}" pattern="HH:mm:ss"/></td>
                                        <td>
                                            <c:choose>
                                                <c:when test="${rec.checkOut != null}"><fmt:formatDate value="${rec.checkOut}" pattern="HH:mm:ss"/></c:when>
                                                <c:otherwise>—</c:otherwise>
                                            </c:choose>
                                        </td>
                                        <td>
                                            <c:choose>
                                                <c:when test="${rec.status == '迟到'}"><span class="badge-soft err">迟到</span></c:when>
                                                <c:when test="${rec.status == '补签'}"><span class="badge-soft warn">补签</span></c:when>
                                                <c:when test="${rec.checkOut == null}"><span class="badge-soft warn">未签退</span></c:when>
                                                <c:otherwise><span class="badge-soft ok">正常</span></c:otherwise>
                                            </c:choose>
                                        </td>
                                        <td><fmt:formatDate value="${rec.date}" pattern="yyyy-MM-dd"/></td>
                                        <c:if test="${loginUser.role == 'admin'}">
                                            <td style="text-align:right;">
                                                <c:if test="${rec.status != '迟到'}">
                                                    <a class="btn-icon del" title="记迟到" href="${pageContext.request.contextPath}/attendance?action=markLate&id=${rec.id}" onclick="return confirm('确定将该记录记为迟到吗？');"><i class="bi bi-alarm"></i></a>
                                                </c:if>
                                            </td>
                                        </c:if>
                                    </tr>
                                </c:forEach>
                            </c:when>
                            <c:otherwise>
                                <tr><td colspan="${loginUser.role == 'admin' ? 7 : 6}" class="empty-row">暂无考勤记录</td></tr>
                            </c:otherwise>
                        </c:choose>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>