<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>员工管理 · 智能员工管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="${pageContext.request.contextPath}/assets/css/app.css" rel="stylesheet">
</head>
<body>
<c:set var="activePage" value="employee" scope="page"/>
<%@ include file="/includes/sidebar.jspf" %>

<div class="main-content">
    <div class="top-bar">
        <div class="welcome">
            <h4>员工管理</h4>
            <div class="date">维护员工档案、部门归属与职位信息</div>
        </div>
        <span class="role-badge ${loginUser.role == 'admin' ? 'admin' : ''}"><i class="bi bi-shield-check"></i>${loginUser.role == 'admin' ? '管理员' : '普通用户'}</span>
    </div>

    <div class="content-area">
        <div class="panel">
            <div class="toolbar">
                <form class="search-box" action="${pageContext.request.contextPath}/employee" method="get">
                    <input type="hidden" name="action" value="search">
                    <i class="bi bi-search"></i>
                    <input type="text" name="keyword" value="${keyword}" placeholder="搜索姓名 / 电话 / 邮箱，回车搜索">
                </form>
                <div class="toolbar-actions">
                    <c:if test="${not empty keyword}">
                        <a class="btn-soft" href="${pageContext.request.contextPath}/employee"><i class="bi bi-arrow-counterclockwise"></i>重置</a>
                    </c:if>
                    <a class="btn-grad" href="${pageContext.request.contextPath}/employee?action=add"><i class="bi bi-plus-lg"></i>添加员工</a>
                </div>
            </div>

            <div style="overflow-x:auto;">
                <table class="table-dash">
                    <thead>
                        <tr>
                            <th>姓名</th><th>性别</th><th>电话</th><th>邮箱</th><th>部门</th><th>职位</th><th>入职日期</th><th style="text-align:right;">操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:choose>
                            <c:when test="${not empty employees}">
                                <c:forEach var="emp" items="${employees}">
                                    <tr>
                                        <td><span class="avatar">${fn:substring(emp.name, 0, 1)}</span>${emp.name}</td>
                                        <td><span class="badge-soft ${emp.gender == '女' ? 'warn' : 'ok'}">${emp.gender}</span></td>
                                        <td>${emp.phone}</td>
                                        <td>${emp.email}</td>
                                        <td><span class="tag">部门 #${emp.deptId}</span></td>
                                        <td>${emp.position}</td>
                                        <td><fmt:formatDate value="${emp.hireDate}" pattern="yyyy-MM-dd"/></td>
                                        <td style="text-align:right; white-space:nowrap;">
                                            <a class="btn-icon edit" title="编辑" href="${pageContext.request.contextPath}/employee?action=edit&id=${emp.id}"><i class="bi bi-pencil"></i></a>
                                            <a class="btn-icon del" title="删除" href="${pageContext.request.contextPath}/employee?action=delete&id=${emp.id}" onclick="return confirm('确定删除员工「${emp.name}」吗？此操作不可恢复。');"><i class="bi bi-trash"></i></a>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </c:when>
                            <c:otherwise>
                                <tr><td colspan="8" class="empty-row">暂无员工数据</td></tr>
                            </c:otherwise>
                        </c:choose>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>