<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>数据看板 · 智能员工管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="${pageContext.request.contextPath}/assets/css/app.css" rel="stylesheet">
    <style>
        .ai-fab {
            position: fixed;
            right: 32px;
            bottom: 32px;
            width: 56px;
            height: 56px;
            border-radius: 50%;
            background: linear-gradient(135deg, #1e3c72 0%, #6a11cb 100%);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.55rem;
            text-decoration: none;
            box-shadow: 0 8px 24px rgba(106, 17, 203, 0.40);
            transition: transform 0.25s ease, box-shadow 0.25s ease;
            z-index: 1050;
        }
        .ai-fab:hover {
            transform: scale(1.12);
            box-shadow: 0 12px 32px rgba(106, 17, 203, 0.55);
        }
    </style>
</head>
<body>
<c:if test="${empty loginUser}">
    <c:redirect url="/login.jsp"/>
</c:if>
<c:set var="activePage" value="dashboard" scope="page"/>
<%@ include file="/includes/sidebar.jspf" %>

<div class="main-content">
    <div class="top-bar">
        <div class="welcome">
            <h4>欢迎回来，${loginUser.username} 👋</h4>
            <div class="date" id="todayDate"></div>
        </div>
        <div class="top-actions">
            <button class="btn-soft" id="btnRefresh" title="立即刷新数据"><i class="bi bi-arrow-clockwise" id="refreshIcon"></i>刷新</button>
            <span class="role-badge ${loginUser.role == 'admin' ? 'admin' : ''}"><i class="bi bi-shield-check"></i>${loginUser.role == 'admin' ? '管理员' : (loginUser.role == 'guest' ? '游客' : '普通用户')}</span>
        </div>
    </div>

    <div class="content-area">
        <div class="row g-4">
            <div class="col-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon ic-blue"><i class="bi bi-people"></i></div>
                    <div class="stat-info"><div class="num" id="statEmployee">0</div><div class="label">员工总数</div></div>
                </div>
            </div>
            <div class="col-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon ic-green"><i class="bi bi-diagram-3"></i></div>
                    <div class="stat-info"><div class="num" id="statDept">0</div><div class="label">部门总数</div></div>
                </div>
            </div>
            <div class="col-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon ic-orange"><i class="bi bi-calendar-check"></i></div>
                    <div class="stat-info"><div class="num" id="statCheckIn">0</div><div class="label">今日签到人数</div></div>
                </div>
            </div>
            <div class="col-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon ic-red"><i class="bi bi-exclamation-triangle"></i></div>
                    <div class="stat-info"><div class="num" id="statAbnormal">0</div><div class="label">今日异常考勤</div></div>
                </div>
            </div>
        </div>

        <div class="row g-4 mt-1">
            <div class="col-12 col-lg-6">
                <div class="panel">
                    <h5 class="panel-title">部门人数分布</h5>
                    <div class="chart-box" id="pieChart"></div>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="panel">
                    <h5 class="panel-title">最近 7 天考勤趋势</h5>
                    <div class="chart-box" id="lineChart"></div>
                </div>
            </div>
        </div>

        <div class="panel">
            <h5 class="panel-title">最近入职员工</h5>
            <table class="table-dash">
                <thead>
                    <tr><th>姓名</th><th>性别</th><th>职位</th><th>所属部门</th><th>入职日期</th></tr>
                </thead>
                <tbody id="recentBody">
                    <tr><td colspan="5" class="empty-row">加载中…</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    var CTX = '${pageContext.request.contextPath}';
    var PALETTE = ['#1e3c72', '#2a5298', '#4a6cf7', '#6a5acd', '#8e44ec', '#6a11cb', '#9b59b6', '#5568c9'];
    var pieChart = null, lineChart = null, firstLoad = true;

    document.getElementById('todayDate').textContent = formatDate(new Date());

    function formatDate(d) {
        var week = ['周日','周一','周二','周三','周四','周五','周六'];
        var y = d.getFullYear();
        var m = String(d.getMonth() + 1).padStart(2, '0');
        var day = String(d.getDate()).padStart(2, '0');
        return y + '年' + m + '月' + day + '日 · ' + week[d.getDay()];
    }

    function animateValue(el, end) {
        var duration = 900, startTime = null;
        function step(ts) {
            if (!startTime) startTime = ts;
            var p = Math.min((ts - startTime) / duration, 1);
            var eased = 1 - Math.pow(1 - p, 3);
            el.textContent = Math.floor(eased * end);
            if (p < 1) requestAnimationFrame(step);
            else el.textContent = end;
        }
        requestAnimationFrame(step);
    }

    function setStat(id, value, animate) {
        var el = document.getElementById(id);
        if (animate) animateValue(el, value);
        else el.textContent = value;
    }

    function loadDashboard(animate) {
        fetch(CTX + '/api/dashboard', { headers: { 'Accept': 'application/json' }, cache: 'no-store' })
            .then(function (r) {
                if (r.status === 401) { window.location.href = CTX + '/login.jsp'; throw new Error('未登录'); }
                return r.json();
            })
            .then(function (data) {
                setStat('statEmployee', data.employeeTotal, animate);
                setStat('statDept', data.departmentTotal, animate);
                setStat('statCheckIn', data.todayCheckIn, animate);
                setStat('statAbnormal', data.todayAbnormal, animate);
                renderRecent(data.recent);
                ensureECharts()
                    .then(function () {
                        renderPie(data.deptDist);
                        renderLine(data.trendDays, data.trendCounts);
                    })
                    .catch(function (err) {
                        console.error('图表库加载失败：', err);
                        showChartFallback('图表加载失败，请检查网络后刷新');
                    });
            })
            .catch(function (err) { console.error('看板数据加载失败：', err); });
    }

    function ensureECharts() {
        return new Promise(function (resolve, reject) {
            if (window.echarts) return resolve();
            var s = document.createElement('script');
            s.src = 'https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js';
            s.async = true;
            s.onload = function () { resolve(); };
            s.onerror = function () { reject(new Error('ECharts CDN 不可达')); };
            document.body.appendChild(s);
        });
    }

    function showChartFallback(msg) {
        ['pieChart', 'lineChart'].forEach(function (id) {
            var el = document.getElementById(id);
            if (el) el.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#9ca3af;font-size:0.9rem;">' + msg + '</div>';
        });
    }

    function renderPie(dist) {
        pieChart = pieChart || echarts.init(document.getElementById('pieChart'));
        pieChart.setOption({
            color: PALETTE,
            tooltip: { trigger: 'item', formatter: '{b}: {c} 人 ({d}%)' },
            legend: { bottom: 0, icon: 'circle', itemWidth: 8, textStyle: { color: '#6b7280' } },
            series: [{
                name: '部门人数', type: 'pie', radius: ['45%', '70%'], center: ['50%', '45%'],
                avoidLabelOverlap: true,
                itemStyle: { borderRadius: 8, borderColor: '#fff', borderWidth: 2 },
                label: { show: false },
                data: (dist || [])
            }]
        });
    }

    function renderLine(days, counts) {
        lineChart = lineChart || echarts.init(document.getElementById('lineChart'));
        lineChart.setOption({
            color: ['#2a5298'],
            tooltip: { trigger: 'axis' },
            grid: { left: 40, right: 20, top: 30, bottom: 40 },
            xAxis: {
                type: 'category', boundaryGap: false, data: days || [],
                axisLine: { lineStyle: { color: '#e5e7eb' } }, axisLabel: { color: '#6b7280' }
            },
            yAxis: { type: 'value', splitLine: { lineStyle: { color: '#f0f1f4' } }, axisLabel: { color: '#6b7280' } },
            series: [{
                name: '签到人数', type: 'line', smooth: true, symbol: 'circle', symbolSize: 8,
                lineStyle: { width: 3 },
                itemStyle: { color: '#6a11cb', borderColor: '#fff', borderWidth: 2 },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [
                        { offset: 0, color: 'rgba(74,108,247,0.35)' },
                        { offset: 1, color: 'rgba(106,17,203,0.02)' }
                    ])
                },
                data: counts || []
            }]
        });
    }

    function renderRecent(list) {
        var tbody = document.getElementById('recentBody');
        if (!list || list.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="empty-row">暂无数据</td></tr>';
            return;
        }
        var html = '';
        for (var i = 0; i < list.length; i++) {
            var e = list[i];
            html += '<tr>'
                + '<td><span class="avatar">' + escapeHtml((e.name || '?').charAt(0)) + '</span>' + escapeHtml(e.name) + '</td>'
                + '<td>' + escapeHtml(e.gender) + '</td>'
                + '<td>' + escapeHtml(e.position) + '</td>'
                + '<td><span class="tag">' + escapeHtml(e.deptName || '未分配') + '</span></td>'
                + '<td>' + escapeHtml(e.hireDate) + '</td>'
                + '</tr>';
        }
        tbody.innerHTML = html;
    }

    function escapeHtml(s) {
        if (s == null) return '';
        return String(s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    document.getElementById('btnRefresh').addEventListener('click', function () {
        var ic = document.getElementById('refreshIcon');
        ic.classList.add('spin');
        loadDashboard(true);
        setTimeout(function () { ic.classList.remove('spin'); }, 900);
    });

    window.addEventListener('focus', function () { loadDashboard(false); });
    setInterval(function () { loadDashboard(false); }, 30000);
    window.addEventListener('resize', function () {
        if (pieChart) pieChart.resize();
        if (lineChart) lineChart.resize();
    });

    loadDashboard(true);
</script>

<a class="ai-fab" href="${pageContext.request.contextPath}/ai_chat.jsp" title="AI 智能助手">
    <i class="bi bi-robot"></i>
</a>

</body>
</html>