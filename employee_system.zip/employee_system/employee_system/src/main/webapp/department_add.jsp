<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>添加部门 · 智能员工管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="${pageContext.request.contextPath}/assets/css/app.css" rel="stylesheet">
</head>
<body>
<c:set var="activePage" value="department" scope="page"/>
<%@ include file="/includes/sidebar.jspf" %>

<div class="main-content">
    <div class="top-bar">
        <div class="welcome"><h4>添加部门</h4><div class="date">创建新的组织部门</div></div>
        <span class="role-badge ${loginUser.role == 'admin' ? 'admin' : ''}"><i class="bi bi-shield-check"></i>${loginUser.role == 'admin' ? '管理员' : '普通用户'}</span>
    </div>
    <div class="content-area">
        <div class="panel form-card">
            <h5 class="panel-title">部门信息</h5>
            <form action="${pageContext.request.contextPath}/department" method="post">
                <input type="hidden" name="action" value="insert">
                <div class="field"><label>部门名称 <span class="req">*</span></label><input class="form-input" type="text" name="name" required></div>
                <div class="field"><label>负责人</label><input class="form-input" type="text" name="manager"></div>
                <div class="field"><label>部门描述</label><textarea class="form-input" name="description" rows="3" placeholder="简述部门职责"></textarea></div>
                <div class="form-actions">
                    <button type="submit" class="btn-grad"><i class="bi bi-check-lg"></i>提交保存</button>
                    <a class="btn-soft" href="${pageContext.request.contextPath}/department">返回列表</a>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>