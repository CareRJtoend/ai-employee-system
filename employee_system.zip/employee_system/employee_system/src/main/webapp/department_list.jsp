<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>部门管理 · 智能员工管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="${pageContext.request.contextPath}/assets/css/app.css" rel="stylesheet">
</head>
<body>
<c:set var="activePage" value="department" scope="page"/>
<%@ include file="/includes/sidebar.jspf" %>

<div class="main-content">
    <div class="top-bar">
        <div class="welcome">
            <h4>部门管理</h4>
            <div class="date">组织架构、负责人与部门职责维护</div>
        </div>
        <span class="role-badge ${loginUser.role == 'admin' ? 'admin' : ''}"><i class="bi bi-shield-check"></i>${loginUser.role == 'admin' ? '管理员' : '普通用户'}</span>
    </div>

    <div class="content-area">
        <div class="panel">
            <div class="toolbar">
                <h5 class="panel-title" style="margin:0;">部门列表（共 ${fn:length(departments)} 个）</h5>
                <div class="toolbar-actions">
                    <a class="btn-grad" href="${pageContext.request.contextPath}/department?action=add"><i class="bi bi-plus-lg"></i>添加部门</a>
                </div>
            </div>

            <div style="overflow-x:auto;">
                <table class="table-dash">
                    <thead>
                        <tr><th>ID</th><th>部门名称</th><th>负责人</th><th>描述</th><th style="text-align:right;">操作</th></tr>
                    </thead>
                    <tbody>
                        <c:choose>
                            <c:when test="${not empty departments}">
                                <c:forEach var="dept" items="${departments}">
                                    <tr>
                                        <td><span class="tag">#${dept.id}</span></td>
                                        <td><strong>${dept.name}</strong></td>
                                        <td>${dept.manager}</td>
                                        <td>${dept.description}</td>
                                        <td style="text-align:right; white-space:nowrap;">
                                            <a class="btn-icon edit" title="编辑" href="${pageContext.request.contextPath}/department?action=edit&id=${dept.id}"><i class="bi bi-pencil"></i></a>
                                            <a class="btn-icon del" title="删除" href="${pageContext.request.contextPath}/department?action=delete&id=${dept.id}" onclick="return confirm('确定删除部门「${dept.name}」吗？');"><i class="bi bi-trash"></i></a>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </c:when>
                            <c:otherwise>
                                <tr><td colspan="5" class="empty-row">暂无部门数据</td></tr>
                            </c:otherwise>
                        </c:choose>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>