<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>注册 · 智能员工管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --brand-1: #1e3c72;
            --brand-2: #2a5298;
            --brand-3: #6a11cb;
            --text-dark: #1a1f36;
            --text-muted: #6b7280;
            --border: #e5e7eb;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: "Segoe UI", "PingFang SC", "Microsoft YaHei", system-ui, sans-serif; }
        body { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: #eef1f6; padding: 24px; }
        .shell { display: flex; width: 100%; max-width: 1000px; min-height: 620px; background: #fff; border-radius: 24px; overflow: hidden; box-shadow: 0 24px 60px -20px rgba(30,60,114,0.45); animation: enter 0.7s cubic-bezier(0.16,1,0.3,1) both; }
        @keyframes enter { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: translateY(0); } }
        .brand { position: relative; flex: 1 1 46%; padding: 56px 48px; background: linear-gradient(150deg, var(--brand-1) 0%, var(--brand-2) 45%, var(--brand-3) 100%); color: #fff; display: flex; flex-direction: column; justify-content: space-between; overflow: hidden; }
        .brand::before, .brand::after { content: ""; position: absolute; border-radius: 50%; filter: blur(2px); }
        .brand::before { width: 320px; height: 320px; top: -120px; right: -100px; background: radial-gradient(circle, rgba(255,255,255,0.14), transparent 70%); }
        .brand::after { width: 260px; height: 260px; bottom: -80px; left: -70px; background: radial-gradient(circle, rgba(255,255,255,0.10), transparent 70%); }
        .brand-grid { position: absolute; inset: 0; background-image: linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px); background-size: 44px 44px; mask-image: radial-gradient(circle at 30% 20%, #000 0%, transparent 75%); -webkit-mask-image: radial-gradient(circle at 30% 20%, #000 0%, transparent 75%); pointer-events: none; }
        .brand > * { position: relative; z-index: 1; }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-mark { width: 46px; height: 46px; border-radius: 13px; background: rgba(255,255,255,0.16); border: 1px solid rgba(255,255,255,0.28); display: flex; align-items: center; justify-content: center; }
        .logo-mark svg { width: 26px; height: 26px; }
        .logo-text { font-size: 1.05rem; font-weight: 600; letter-spacing: 0.5px; }
        .brand-copy h1 { font-size: 2.1rem; font-weight: 700; line-height: 1.3; margin-bottom: 14px; }
        .brand-copy p { font-size: 0.95rem; line-height: 1.8; color: rgba(255,255,255,0.78); max-width: 320px; }
        .features { margin-top: 34px; display: flex; flex-direction: column; gap: 18px; }
        .feature { display: flex; align-items: center; gap: 14px; font-size: 0.92rem; color: rgba(255,255,255,0.92); }
        .feature i { width: 38px; height: 38px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; border-radius: 10px; background: rgba(255,255,255,0.14); border: 1px solid rgba(255,255,255,0.18); font-size: 1.05rem; }
        .brand-foot { font-size: 0.8rem; color: rgba(255,255,255,0.55); }
        .form-side { flex: 1 1 54%; padding: 48px 60px; display: flex; flex-direction: column; justify-content: center; }
        .form-head h2 { font-size: 1.7rem; font-weight: 700; color: var(--text-dark); margin-bottom: 8px; }
        .form-head p { color: var(--text-muted); font-size: 0.92rem; margin-bottom: 26px; }
        .field { margin-bottom: 18px; }
        .field label { display: block; font-size: 0.85rem; font-weight: 600; color: #374151; margin-bottom: 8px; }
        .input-wrap { position: relative; display: flex; align-items: center; }
        .input-wrap > i.lead { position: absolute; left: 16px; color: #9ca3af; font-size: 1.05rem; transition: color 0.25s; }
        .input-wrap input { width: 100%; padding: 14px 16px 14px 46px; border: 1.5px solid var(--border); border-radius: 12px; font-size: 0.95rem; color: var(--text-dark); background: #fafbfc; outline: none; transition: all 0.25s; }
        .input-wrap input::placeholder { color: #b0b6c0; }
        .input-wrap input:focus { background: #fff; border-color: var(--brand-2); box-shadow: 0 0 0 4px rgba(42,82,152,0.12); }
        .input-wrap:focus-within > i.lead { color: var(--brand-2); }
        .toggle-pwd { position: absolute; right: 14px; background: none; border: none; color: #9ca3af; cursor: pointer; font-size: 1.05rem; padding: 4px; transition: color 0.2s; }
        .toggle-pwd:hover { color: var(--brand-2); }
        .err-msg { color: #dc2626; font-size: 0.78rem; margin-top: 5px; min-height: 1em; }
        .btn-register { position: relative; width: 100%; padding: 15px; border: none; border-radius: 12px; background: linear-gradient(135deg, var(--brand-2) 0%, var(--brand-3) 100%); color: #fff; font-size: 1rem; font-weight: 600; letter-spacing: 1px; cursor: pointer; overflow: hidden; transition: transform 0.2s ease, box-shadow 0.2s ease; box-shadow: 0 6px 18px rgba(42,82,152,0.3); margin-top: 8px; }
        .btn-register:hover { transform: translateY(-2px); box-shadow: 0 12px 26px rgba(106,17,203,0.38); }
        .btn-register:active { transform: translateY(0); }
        .btn-register:disabled { opacity: 0.7; cursor: not-allowed; transform: none; }
        .alert-err { display: flex; align-items: center; gap: 8px; background: #fef2f2; border: 1px solid #fecaca; color: #dc2626; border-radius: 10px; padding: 11px 14px; font-size: 0.87rem; margin-bottom: 20px; animation: shake 0.4s ease; }
        @keyframes shake { 0%,100%{transform:translateX(0)} 25%{transform:translateX(-5px)} 75%{transform:translateX(5px)} }
        .signup { text-align: center; margin-top: 22px; font-size: 0.88rem; color: var(--text-muted); }
        .link { font-size: 0.86rem; color: var(--brand-2); text-decoration: none; font-weight: 500; }
        .link:hover { text-decoration: underline; }
        .strength-bar { height: 4px; border-radius: 2px; background: #e5e7eb; margin-top: 6px; overflow: hidden; }
        .strength-bar .fill { height: 100%; border-radius: 2px; transition: all 0.3s; width: 0; }
        @media (max-width: 860px) { body { padding: 0; align-items: stretch; } .shell { flex-direction: column; max-width: 460px; min-height: auto; border-radius: 0; margin: auto; } .brand { padding: 40px 32px; flex: none; } .brand-copy h1 { font-size: 1.6rem; } .features { display: none; } .brand-foot { display: none; } .form-side { padding: 40px 32px; } }
    </style>
</head>
<body>
<div class="shell">
    <div class="brand">
        <div class="brand-grid"></div>
        <div class="logo">
            <div class="logo-mark">
                <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="9" cy="7" r="3"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><path d="M16 4.5a3 3 0 0 1 0 5.6"/><path d="M18 14c2 .8 3.4 2.7 3.4 5"/>
                </svg>
            </div>
            <span class="logo-text">智能员工管理系统</span>
        </div>
        <div class="brand-copy">
            <h1>加入我们<br>开启高效管理</h1>
            <p>创建您的专属账号，体验一站式员工档案、考勤与部门协同管理服务。</p>
            <div class="features">
                <div class="feature"><i class="bi bi-lightning-charge"></i><span>30 秒极速注册</span></div>
                <div class="feature"><i class="bi bi-lock"></i><span>数据隔离，安全可靠</span></div>
                <div class="feature"><i class="bi bi-free"></i><span>完全免费使用</span></div>
            </div>
        </div>
        <div class="brand-foot">© 2026 Employee System · 保留所有权利</div>
    </div>

    <div class="form-side">
        <div class="form-head">
            <h2>创建账号</h2>
            <p>填写以下信息完成注册</p>
        </div>

        <% if (request.getAttribute("error") != null) { %>
        <div class="alert-err">
            <i class="bi bi-exclamation-circle-fill"></i><span>${error}</span>
        </div>
        <% } %>

        <form action="${pageContext.request.contextPath}/register" method="post" id="regForm" novalidate>
            <div class="field">
                <label for="username">用户名</label>
                <div class="input-wrap">
                    <i class="bi bi-person lead"></i>
                    <input type="text" id="username" name="username" placeholder="3-20个字符，字母或数字" value="${oldUsername}" required>
                </div>
                <div class="err-msg" id="errUsername"></div>
            </div>
            <div class="field">
                <label for="password">密码</label>
                <div class="input-wrap">
                    <i class="bi bi-lock lead"></i>
                    <input type="password" id="password" name="password" placeholder="至少 4 位密码" required>
                    <button type="button" class="toggle-pwd" onclick="togglePwd('password','eye1')"><i class="bi bi-eye" id="eye1"></i></button>
                </div>
                <div class="strength-bar"><div class="fill" id="strengthFill"></div></div>
                <div class="err-msg" id="errPassword"></div>
            </div>
            <div class="field">
                <label for="confirmPassword">确认密码</label>
                <div class="input-wrap">
                    <i class="bi bi-shield-lock lead"></i>
                    <input type="password" id="confirmPassword" name="confirmPassword" placeholder="再次输入密码" required>
                    <button type="button" class="toggle-pwd" onclick="togglePwd('confirmPassword','eye2')"><i class="bi bi-eye" id="eye2"></i></button>
                </div>
                <div class="err-msg" id="errConfirm"></div>
            </div>

            <button type="submit" class="btn-register" id="regBtn">注 册</button>
        </form>

        <div class="signup">
            已有账号？<a href="${pageContext.request.contextPath}/login.jsp" class="link">返回登录</a>
        </div>
    </div>
</div>

<script>
    var regForm = document.getElementById('regForm');
    var regBtn = document.getElementById('regBtn');

    regForm.addEventListener('submit', function (e) {
        var u = document.getElementById('username');
        var p = document.getElementById('password');
        var c = document.getElementById('confirmPassword');
        var eu = document.getElementById('errUsername');
        var ep = document.getElementById('errPassword');
        var ec = document.getElementById('errConfirm');
        eu.textContent = ''; ep.textContent = ''; ec.textContent = '';
        var ok = true;

        if (!u.value.trim()) { eu.textContent = '用户名不能为空'; ok = false; }
        else if (u.value.trim().length < 3 || u.value.trim().length > 20) { eu.textContent = '用户名长度需在 3-20 个字符之间'; ok = false; }

        if (!p.value) { ep.textContent = '密码不能为空'; ok = false; }
        else if (p.value.length < 4) { ep.textContent = '密码长度至少 4 位'; ok = false; }

        if (!c.value) { ec.textContent = '请确认密码'; ok = false; }
        else if (p.value !== c.value) { ec.textContent = '两次密码不一致'; ok = false; }

        if (!ok) { e.preventDefault(); return; }
        regBtn.disabled = true;
        regBtn.textContent = '注册中…';
    });

    document.getElementById('password').addEventListener('input', function () {
        var val = this.value;
        var fill = document.getElementById('strengthFill');
        var pct = 0, color = '#e5e7eb';
        if (val.length >= 4) { pct = 33; color = '#f97316'; }
        if (val.length >= 8) { pct = 66; color = '#eab308'; }
        if (val.length >= 8 && /[A-Z]/.test(val) && /[0-9]/.test(val)) { pct = 100; color = '#10b981'; }
        fill.style.width = pct + '%';
        fill.style.background = color;
    });

    function togglePwd(inputId, iconId) {
        var input = document.getElementById(inputId);
        var icon = document.getElementById(iconId);
        if (input.type === 'password') { input.type = 'text'; icon.className = 'bi bi-eye-slash'; }
        else { input.type = 'password'; icon.className = 'bi bi-eye'; }
    }
</script>
</body>
</html>