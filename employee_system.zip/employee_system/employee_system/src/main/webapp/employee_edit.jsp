<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>编辑员工 · 智能员工管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="${pageContext.request.contextPath}/assets/css/app.css" rel="stylesheet">
</head>
<body>
<c:set var="activePage" value="employee" scope="page"/>
<%@ include file="/includes/sidebar.jspf" %>

<div class="main-content">
    <div class="top-bar">
        <div class="welcome"><h4>编辑员工</h4><div class="date">修改员工 #${employee.id} 的档案信息</div></div>
        <span class="role-badge ${loginUser.role == 'admin' ? 'admin' : ''}"><i class="bi bi-shield-check"></i>${loginUser.role == 'admin' ? '管理员' : '普通用户'}</span>
    </div>

    <div class="content-area">
        <div class="panel form-card">
            <h5 class="panel-title">员工信息</h5>
            <form action="${pageContext.request.contextPath}/employee" method="post">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" value="${employee.id}">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="field"><label>姓名 <span class="req">*</span></label><input class="form-input" type="text" name="name" value="${employee.name}" required></div>
                    </div>
                    <div class="col-md-6">
                        <div class="field"><label>性别</label>
                            <select class="form-input" name="gender">
                                <option value="男" ${employee.gender == '男' ? 'selected' : ''}>男</option>
                                <option value="女" ${employee.gender == '女' ? 'selected' : ''}>女</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="field"><label>电话</label><input class="form-input" type="text" name="phone" value="${employee.phone}"></div>
                    </div>
                    <div class="col-md-6">
                        <div class="field"><label>邮箱</label><input class="form-input" type="email" name="email" value="${employee.email}"></div>
                    </div>
                    <div class="col-md-6">
                        <div class="field"><label>部门</label>
                            <select class="form-input" name="deptId">
                                <option value="">请选择部门</option>
                                <c:forEach var="dept" items="${departments}">
                                    <option value="${dept.id}" ${dept.id == employee.deptId ? 'selected' : ''}>${dept.name}</option>
                                </c:forEach>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="field"><label>职位</label><input class="form-input" type="text" name="position" value="${employee.position}"></div>
                    </div>
                    <div class="col-md-6">
                        <div class="field"><label>入职日期</label><input class="form-input" type="date" name="hireDate" value="<fmt:formatDate value='${employee.hireDate}' pattern='yyyy-MM-dd'/>"></div>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn-grad"><i class="bi bi-check-lg"></i>保存修改</button>
                    <a class="btn-soft" href="${pageContext.request.contextPath}/employee">返回列表</a>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>