<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI 智能助手 · 智能员工管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="${pageContext.request.contextPath}/assets/css/app.css" rel="stylesheet">
    <style>
        .chat-panel {
            display: flex;
            flex-direction: column;
            height: calc(100vh - 48px);
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 8px 30px rgba(30, 60, 114, 0.10);
            overflow: hidden;
            margin: 24px;
        }
        .chat-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 24px;
            background: linear-gradient(135deg, #1e3c72 0%, #6a11cb 100%);
            color: #fff;
        }
        .chat-header .ai-title { display: flex; align-items: center; gap: 12px; }
        .chat-header .ai-avatar {
            width: 42px; height: 42px; border-radius: 50%;
            background: rgba(255,255,255,0.18);
            backdrop-filter: blur(6px);
            display: flex; align-items: center; justify-content: center;
            font-size: 1.4rem;
        }
        .chat-header h5 { margin: 0; font-weight: 600; }
        .chat-header .sub { font-size: 0.78rem; opacity: 0.75; }
        .btn-clear {
            background: rgba(255,255,255,0.15);
            border: 1px solid rgba(255,255,255,0.3);
            color: #fff; border-radius: 8px;
            padding: 6px 14px; font-size: 0.85rem;
            transition: all 0.2s;
        }
        .btn-clear:hover { background: rgba(255,255,255,0.3); }

        .chat-body {
            flex: 1; overflow-y: auto;
            padding: 24px;
            background: #f4f6fb;
        }
        .msg-row { display: flex; margin-bottom: 20px; align-items: flex-start; gap: 10px; }
        .msg-row.user { flex-direction: row-reverse; }
        .msg-avatar {
            width: 38px; height: 38px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.1rem; color: #fff; flex-shrink: 0;
        }
        .msg-row.ai .msg-avatar { background: linear-gradient(135deg, #6a5acd, #6a11cb); }
        .msg-row.user .msg-avatar { background: linear-gradient(135deg, #1e3c72, #2a5298); }
        .msg-bubble {
            max-width: 70%;
            padding: 12px 16px;
            border-radius: 14px;
            font-size: 0.95rem;
            line-height: 1.6;
            word-break: break-word;
            white-space: pre-wrap;
            animation: msgIn 0.25s ease;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .msg-row.ai .msg-bubble { background: #fff; color: #2c3e50; border-top-left-radius: 4px; }
        .msg-row.user .msg-bubble {
            background: linear-gradient(135deg, #1e3c72, #4a6cf7);
            color: #fff; border-top-right-radius: 4px;
        }
        .msg-time { font-size: 0.7rem; opacity: 0.55; margin-top: 6px; }
        @keyframes msgIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: none; } }

        .typing { display: inline-flex; gap: 5px; align-items: center; padding: 4px 2px; }
        .typing span {
            width: 8px; height: 8px; border-radius: 50%;
            background: #6a5acd; display: inline-block;
            animation: bounce 1.2s infinite ease-in-out;
        }
        .typing span:nth-child(2) { animation-delay: 0.15s; }
        .typing span:nth-child(3) { animation-delay: 0.3s; }
        @keyframes bounce { 0%, 60%, 100% { transform: translateY(0); } 30% { transform: translateY(-7px); } }

        .quick-bar { display: flex; gap: 8px; flex-wrap: wrap; padding: 10px 20px 0; background: #f4f6fb; }
        .quick-btn {
            background: #fff; border: 1px solid #dbe2f0; color: #3a5ba0;
            border-radius: 16px; padding: 5px 14px; font-size: 0.8rem;
            cursor: pointer; transition: all 0.2s;
        }
        .quick-btn:hover {
            background: linear-gradient(135deg, #1e3c72, #6a11cb);
            color: #fff; border-color: transparent;
        }

        .chat-input-bar {
            display: flex; align-items: flex-end; gap: 12px;
            padding: 12px 20px 8px; background: #f4f6fb;
            border-top: 1px solid #e6e9f2;
        }
        .chat-input-bar textarea {
            flex: 1; resize: none; border-radius: 12px;
            border: 1px solid #dbe2f0; padding: 10px 14px;
            max-height: 120px; font-size: 0.95rem;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        .chat-input-bar textarea:focus {
            outline: none; border-color: #4a6cf7;
            box-shadow: 0 0 0 3px rgba(74, 108, 247, 0.15);
        }
        .btn-send {
            background: linear-gradient(135deg, #1e3c72, #6a11cb);
            border: none; color: #fff; border-radius: 12px;
            padding: 10px 22px; font-weight: 500;
            display: flex; align-items: center; gap: 6px;
            transition: all 0.2s;
        }
        .btn-send:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 6px 16px rgba(106, 17, 203, 0.35); }
        .btn-send:disabled { opacity: 0.55; cursor: not-allowed; }
        .input-hint { font-size: 0.72rem; color: #9ca3af; padding: 0 20px 10px; background: #f4f6fb; }

        @media (max-width: 768px) {
            .chat-panel { margin: 10px; height: calc(100vh - 20px); }
            .msg-bubble { max-width: 82%; }
            .chat-header .sub { display: none; }
        }
    </style>
</head>
<body>
<c:if test="${empty loginUser}">
    <c:redirect url="/login.jsp"/>
</c:if>
<c:set var="activePage" value="ai" scope="page"/>
<%@ include file="/includes/sidebar.jspf" %>

<div class="main-content">
    <div class="chat-panel">
        <div class="chat-header">
            <div class="ai-title">
                <div class="ai-avatar"><i class="bi bi-robot"></i></div>
                <div>
                    <h5>AI 智能助手</h5>
                    <div class="sub">基于智谱 GLM-4-Flash 大模型</div>
                </div>
            </div>
            <button class="btn-clear" id="btnClear" type="button">
                <i class="bi bi-trash3"></i> 清空对话
            </button>
        </div>

        <div class="chat-body" id="chatBody"></div>

        <div class="quick-bar">
            <button class="quick-btn" type="button" data-q="系统有多少员工？">系统有多少员工？</button>
            <button class="quick-btn" type="button" data-q="技术部有哪些人？">技术部有哪些人？</button>
            <button class="quick-btn" type="button" data-q="今天考勤怎么样？">今天考勤怎么样？</button>
            <button class="quick-btn" type="button" data-q="给我一些管理建议">给我一些管理建议</button>
        </div>

        <div class="chat-input-bar">
            <textarea id="chatInput" rows="1" placeholder="输入你的问题…"></textarea>
            <button class="btn-send" id="btnSend" type="button"><i class="bi bi-send"></i>发送</button>
        </div>
        <div class="input-hint">按 Enter 发送，Shift + Enter 换行</div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    var CTX = '${pageContext.request.contextPath}';
    var WELCOME = '你好！我是AI智能助手，可以帮你查询员工信息、分析考勤数据等，请问有什么可以帮你的？';
    var sending = false;

    var chatBody = document.getElementById('chatBody');
    var chatInput = document.getElementById('chatInput');
    var btnSend = document.getElementById('btnSend');
    var btnClear = document.getElementById('btnClear');

    function pad2(n) { return String(n).padStart(2, '0'); }
    function nowTime() {
        var d = new Date();
        return pad2(d.getHours()) + ':' + pad2(d.getMinutes());
    }

    function appendMsg(side, text) {
        var row = document.createElement('div');
        row.className = 'msg-row ' + side;

        var avatar = document.createElement('div');
        avatar.className = 'msg-avatar';
        avatar.innerHTML = side === 'user'
            ? '<i class="bi bi-person"></i>'
            : '<i class="bi bi-robot"></i>';

        var wrap = document.createElement('div');
        var bubble = document.createElement('div');
        bubble.className = 'msg-bubble';
        bubble.textContent = text;
        var time = document.createElement('div');
        time.className = 'msg-time';
        time.textContent = nowTime();
        time.style.textAlign = side === 'user' ? 'right' : 'left';

        wrap.appendChild(bubble);
        wrap.appendChild(time);
        row.appendChild(avatar);
        row.appendChild(wrap);
        chatBody.appendChild(row);
        scrollBottom();
        return row;
    }

    function appendTyping() {
        var row = document.createElement('div');
        row.className = 'msg-row ai';
        row.innerHTML =
            '<div class="msg-avatar"><i class="bi bi-robot"></i></div>' +
            '<div class="msg-bubble"><span class="typing"><span></span><span></span><span></span></span></div>';
        chatBody.appendChild(row);
        scrollBottom();
        return row;
    }

    function scrollBottom() {
        chatBody.scrollTop = chatBody.scrollHeight;
    }

    function setSending(v) {
        sending = v;
        btnSend.disabled = v;
        btnSend.innerHTML = v
            ? '<span class="spinner-border spinner-border-sm"></span>思考中'
            : '<i class="bi bi-send"></i>发送';
    }

    function sendMessage(text) {
        if (sending) return;
        text = (text || '').trim();
        if (!text) return;

        appendMsg('user', text);
        chatInput.value = '';
        chatInput.style.height = 'auto';
        var typingRow = appendTyping();
        setSending(true);

        fetch(CTX + '/api/ai/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: text })
        })
            .then(function (r) {
                if (r.status === 401) { return { success: false, error: '登录已过期，请重新登录' }; }
                return r.json();
            })
            .then(function (data) {
                typingRow.remove();
                if (data.success) {
                    appendMsg('ai', data.reply);
                } else {
                    appendMsg('ai', data.error || 'AI 服务异常，请稍后再试');
                }
            })
            .catch(function () {
                typingRow.remove();
                appendMsg('ai', '网络错误，请稍后重试');
            })
            .finally(function () { setSending(false); chatInput.focus(); });
    }

    btnSend.addEventListener('click', function () { sendMessage(chatInput.value); });

    chatInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage(chatInput.value);
        }
    });

    chatInput.addEventListener('input', function () {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    });

    document.querySelectorAll('.quick-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            sendMessage(this.getAttribute('data-q'));
        });
    });

    btnClear.addEventListener('click', function () {
        chatBody.innerHTML = '';
        appendMsg('ai', WELCOME);
        fetch(CTX + '/api/ai/chat?clear=1', { method: 'GET' }).catch(function () {});
    });

    appendMsg('ai', WELCOME);
</script>
</body>
</html>