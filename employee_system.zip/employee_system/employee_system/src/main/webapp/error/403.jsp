<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>403 · 无权限</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: "Segoe UI", "Microsoft YaHei", sans-serif; }
        body { min-height: 100vh; display: flex; align-items: center; justify-content: center;
               background: #eef1f6; color: #1a1f36; }
        .box { text-align: center; background: #fff; padding: 56px 64px; border-radius: 20px;
               box-shadow: 0 24px 60px -20px rgba(30,60,114,.35); }
        .code { font-size: 5rem; font-weight: 800; background: linear-gradient(135deg,#2a5298,#6a11cb);
                -webkit-background-clip: text; background-clip: text; color: transparent; }
        p { color: #6b7280; margin: 14px 0 28px; font-size: 1rem; }
        a { display: inline-block; padding: 12px 28px; border-radius: 10px; text-decoration: none;
            color: #fff; background: linear-gradient(135deg,#2a5298,#6a11cb); font-weight: 600; }
    </style>
</head>
<body>
<div class="box">
    <div class="code">403</div>
    <p>${empty errorMsg ? "抱歉，你没有权限访问该页面" : errorMsg}</p>
    <a href="${pageContext.request.contextPath}/index.jsp">返回首页</a>
</div>
</body>
</html>